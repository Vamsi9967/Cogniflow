// Lightweight Chrome API mock for the browser-only prototype preview.
(() => {
  const time = Date.now();
  let store = {
    onboardingComplete: true,
    trackingEnabled: true,
    idleRemindersEnabled: false,
    reminderMinutes: 10,
    showTabTitleInReturnAlert: true,
    pendingReturn: { workflowId: "preview-planning", windowId: 1, idleStartedAt: time - 11 * 60_000, notifiedAt: time - 3_000 },
    excludedDomains: ["hr.company.com"],
    workflows: [
      {
        id: "preview-planning",
        title: "Create a LinkedIn post and search jobs",
        createdAt: time - 11 * 60_000,
        lastActive: time - 2 * 60_000,
        tabCount: 5,
        windowId: 1,
        activeUrl: "https://chatgpt.com/c/compose-linkedin-post",
        activeTitle: "Draft a LinkedIn post — ChatGPT",
        tabs: [
          { url: "https://chatgpt.com/c/compose-linkedin-post", title: "Draft a LinkedIn post — ChatGPT", hostname: "chatgpt.com", active: true, lastSeen: time - 2 * 60_000, lastActive: time - 2 * 60_000 },
          { url: "https://www.linkedin.com/jobs/search/", title: "Product design roles — LinkedIn", hostname: "www.linkedin.com", active: false, lastSeen: time - 5 * 60_000, lastActive: time - 5 * 60_000, note: "Finish reviewing saved roles" },
          { url: "https://www.figma.com/design/cogniflow", title: "CogniFlow landing page — Figma", hostname: "www.figma.com", active: false, lastSeen: time - 10 * 60_000, lastActive: time - 10 * 60_000, note: "Refine the feature cards" },
          { url: "https://gemini.google.com/app", title: "Task response — Gemini", hostname: "gemini.google.com", active: false, lastSeen: time - 15 * 60_000, lastActive: time - 15 * 60_000, note: "Check Gemini’s response to the task" }
        ]
      },
      {
        id: "preview-retro",
        title: "Sprint Retro",
        createdAt: time - 3 * 60 * 60_000,
        lastActive: time - 48 * 60_000,
        tabCount: 3,
        windowId: 1,
        activeUrl: "https://miro.com/app/board/sprint-retro",
        activeTitle: "Sprint Retro — Miro",
        tabs: [
          { url: "https://miro.com/app/board/sprint-retro", title: "Sprint Retro — Miro", hostname: "miro.com", active: true, lastSeen: time - 48 * 60_000 },
          { url: "https://linear.app/team/issue/CF-24", title: "CF-24 workflow issue — Linear", hostname: "linear.app", active: false, lastSeen: time - 52 * 60_000 },
          { url: "https://docs.google.com/document/d/sprint-notes", title: "Sprint notes — Google Docs", hostname: "docs.google.com", active: false, lastSeen: time - 54 * 60_000 }
        ]
      }
    ]
  };
  const listeners = [];

  const normalizeKeys = keys => {
    if (keys == null) return Object.keys(store);
    if (Array.isArray(keys)) return keys;
    if (typeof keys === "string") return [keys];
    if (typeof keys === "object") return Object.keys(keys);
    return [];
  };

  window.chrome = {
    storage: {
      local: {
        async get(keys) {
          const result = {};
          for (const key of normalizeKeys(keys)) result[key] = store[key] ?? (typeof keys === "object" && !Array.isArray(keys) ? keys[key] : undefined);
          return result;
        },
        async set(values) {
          const changes = {};
          for (const [key, value] of Object.entries(values)) {
            changes[key] = { oldValue: store[key], newValue: value };
            store[key] = value;
          }
          listeners.forEach(listener => listener(changes, "local"));
        }
      },
      onChanged: { addListener(listener) { listeners.push(listener); } }
    },
    permissions: {
      async request() { return true; },
      async contains() { return true; },
      onRemoved: { addListener() {} }
    },
    runtime: {
      async sendMessage(message) {
        if (message?.type === "CAPTURE_NOW") return { ok: true, result: { tabCount: 5, workflowId: "preview-planning" } };
        return { ok: true };
      }
    },
    windows: { async getLastFocused() { return { id: 1 }; }, async update() { return { id: 1 }; } },
    tabs: {
      async create() { return { id: Math.floor(Math.random() * 10000) }; },
      async query() { return [{ id: 1, windowId: 1 }]; },
      async update() { return { id: 1 }; }
    },
    action: { async setBadgeText() {} }
  };
  window.COGNIFLOW_PREVIEW = true;
})();
