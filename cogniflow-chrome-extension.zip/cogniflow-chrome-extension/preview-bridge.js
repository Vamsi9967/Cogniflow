// Lightweight Chrome API mock for the browser-only prototype preview.
(() => {
  const time = Date.now();
  let store = {
    onboardingComplete: true,
    trackingEnabled: true,
    idleRemindersEnabled: false,
    reminderMinutes: 10,
    showTabTitleInReturnAlert: true,
    pendingReturn: { workflowId: "preview-planning", windowId: 1, idleStartedAt: time - 11 * 60_000, notifiedAt: time - 3_000 },
    excludedDomains: ["hr.company.com"],
    tabRemindersEnabled: true,
    tabReminderMinutes: 20,
    floatingButtonEnabled: false,
    lastFolderId: "preview-jobs",
    // Kept by hand two days ago, which is the point: the automatic memory
    // below holds a day, and these are what outlived it.
    folders: [
      {
        id: "preview-jobs",
        name: "Job applications",
        createdAt: time - 2 * 24 * 60 * 60_000,
        items: [
          { url: "https://boards.greenhouse.io/acme/jobs/41822", title: "Product Designer — Acme", hostname: "boards.greenhouse.io", addedAt: time - 26 * 60 * 60_000, note: "Applied 10 Nov — portfolio + case study sent" },
          { url: "https://jobs.lever.co/northwind/design", title: "Senior Designer, Platform — Northwind", hostname: "jobs.lever.co", addedAt: time - 27 * 60 * 60_000 },
          { url: "https://careers.globex.com/openings/ux-2291", title: "UX Designer (Agentic products) — Globex", hostname: "careers.globex.com", addedAt: time - 2 * 24 * 60 * 60_000, note: "Needs a cover letter" }
        ]
      },
      {
        id: "preview-reading",
        name: "Read later",
        createdAt: time - 5 * 60 * 60_000,
        items: [
          { url: "https://www.nngroup.com/articles/progressive-disclosure/", title: "Progressive Disclosure — NN/g", hostname: "www.nngroup.com", addedAt: time - 5 * 60 * 60_000 }
        ]
      }
    ],
    // Your Gemini task finished while you were in Figma, and you asked to
    // come back to LinkedIn in 20 minutes.
    tabWatch: {
      current: { tabId: 11, since: time - 2 * 60_000 },
      lastNudgeAt: time - 60_000,
      tabs: {
        11: { tabId: 11, windowId: 1, url: "https://chatgpt.com/c/compose-linkedin-post", title: "Draft a LinkedIn post — ChatGPT", hostname: "chatgpt.com", firstSeen: time - 4 * 60_000, engagedMs: 0, leftAt: null, titleChangedAt: null, waitingUntil: null, needsAttention: false, reason: null, nudgedAt: null, doneAt: null },
        12: { tabId: 12, windowId: 1, url: "https://gemini.google.com/app", title: "Task response — Gemini", hostname: "gemini.google.com", firstSeen: time - 40 * 60_000, engagedMs: 4 * 60_000, leftAt: time - 26 * 60_000, titleChangedAt: time - 22 * 60_000, waitingUntil: null, needsAttention: true, reason: "changed", nudgedAt: time - 60_000, doneAt: null, note: "Check Gemini’s answer and copy the summary" },
        13: { tabId: 13, windowId: 1, url: "https://www.linkedin.com/jobs/search/", title: "Product design roles — LinkedIn", hostname: "www.linkedin.com", firstSeen: time - 12 * 60_000, engagedMs: 3 * 60_000, leftAt: time - 5 * 60_000, titleChangedAt: null, waitingUntil: time + 15 * 60_000, needsAttention: false, reason: "waiting", nudgedAt: null, doneAt: null }
      }
    },
    workflows: [
      {
        id: "preview-planning",
        title: "CogniFlow landing page — Figma",
        createdAt: time - 11 * 60_000,
        lastActive: time - 2 * 60_000,
        tabCount: 5,
        windowId: 1,
        activeUrl: "https://chatgpt.com/c/compose-linkedin-post",
        activeTitle: "Draft a LinkedIn post — ChatGPT",
        // Named after Figma, where the time actually went — not ChatGPT,
        // which merely happened to be in front at the last capture.
        anchorUrl: "https://www.figma.com/design/cogniflow",
        tabs: [
          { url: "https://chatgpt.com/c/compose-linkedin-post", title: "Draft a LinkedIn post — ChatGPT", hostname: "chatgpt.com", active: true, activeMs: 4 * 60_000, openedAt: time - 9 * 60_000, closedAt: null, lastSeen: time - 2 * 60_000 },
          { url: "https://www.linkedin.com/jobs/search/", title: "Product design roles — LinkedIn", hostname: "www.linkedin.com", active: false, activeMs: 3 * 60_000, openedFrom: "https://chatgpt.com/c/compose-linkedin-post", openedAt: time - 12 * 60_000, closedAt: null, lastSeen: time - 5 * 60_000 },
          { url: "https://www.figma.com/design/cogniflow", title: "CogniFlow landing page — Figma", hostname: "www.figma.com", active: false, activeMs: 22 * 60_000, openedAt: time - 40 * 60_000, closedAt: null, lastSeen: time - 10 * 60_000 },
          { url: "https://gemini.google.com/app", title: "Task response — Gemini", hostname: "gemini.google.com", active: false, activeMs: 4 * 60_000, openedAt: time - 40 * 60_000, closedAt: null, lastSeen: time - 15 * 60_000 },
          // Closed earlier in the same stretch. Chrome has forgotten these; CogniFlow has not.
          { url: "https://www.figma.com/community/file/typography-scale", title: "Typography scale kit — Figma Community", hostname: "www.figma.com", active: false, openedFrom: "https://www.figma.com/design/cogniflow", openedAt: time - 38 * 60_000, closedAt: time - 24 * 60_000, lastSeen: time - 25 * 60_000 },
          { url: "https://stackoverflow.com/questions/8732/css-grid-minmax", title: "Why does minmax(0,1fr) stop grid blowout? — Stack Overflow", hostname: "stackoverflow.com", active: false, openedFrom: "https://www.figma.com/design/cogniflow", openedAt: time - 33 * 60_000, closedAt: time - 28 * 60_000, lastSeen: time - 29 * 60_000 }
        ]
      },
      {
        id: "preview-retro",
        title: "Sprint Retro",
        createdAt: time - 3 * 60 * 60_000,
        lastActive: time - 48 * 60_000,
        tabCount: 3,
        windowId: 1,
        activeUrl: "https://miro.com/app/board/sprint-retro",
        activeTitle: "Sprint Retro — Miro",
        tabs: [
          { url: "https://miro.com/app/board/sprint-retro", title: "Sprint Retro — Miro", hostname: "miro.com", active: true, lastSeen: time - 48 * 60_000 },
          { url: "https://linear.app/team/issue/CF-24", title: "CF-24 workflow issue — Linear", hostname: "linear.app", active: false, lastSeen: time - 52 * 60_000 },
          { url: "https://docs.google.com/document/d/sprint-notes", title: "Sprint notes — Google Docs", hostname: "docs.google.com", active: false, lastSeen: time - 54 * 60_000 }
        ]
      }
    ]
  };
  const listeners = [];
  const previewTabs = [
    { id: 11, windowId: 1, active: true, url: "https://chatgpt.com/c/compose-linkedin-post", title: "Draft a LinkedIn post — ChatGPT" },
    { id: 12, windowId: 1, active: false, url: "https://gemini.google.com/app", title: "Task response — Gemini" },
    { id: 13, windowId: 1, active: false, url: "https://www.linkedin.com/jobs/search/", title: "Product design roles — LinkedIn" }
  ];

  const normalizeKeys = keys => {
    if (keys == null) return Object.keys(store);
    if (Array.isArray(keys)) return keys;
    if (typeof keys === "string") return [keys];
    if (typeof keys === "object") return Object.keys(keys);
    return [];
  };

  window.chrome = {
    storage: {
      local: {
        async get(keys) {
          const result = {};
          for (const key of normalizeKeys(keys)) result[key] = store[key] ?? (typeof keys === "object" && !Array.isArray(keys) ? keys[key] : undefined);
          return result;
        },
        async set(values) {
          const changes = {};
          for (const [key, value] of Object.entries(values)) {
            changes[key] = { oldValue: store[key], newValue: value };
            store[key] = value;
          }
          listeners.forEach(listener => listener(changes, "local"));
        }
      },
      onChanged: { addListener(listener) { listeners.push(listener); } }
    },
    permissions: {
      async request() { return true; },
      async remove() { return true; },
      async contains() { return true; },
      onRemoved: { addListener() {} }
    },
    runtime: {
      async sendMessage(message) {
        if (message?.type === "CAPTURE_NOW") return { ok: true, result: { tabCount: 5, workflowId: "preview-planning" } };
        if (message?.type === "WORKFLOW_OP") {
          // Same rules the service worker applies, from shared.js.
          const op = message.op;
          const update = { workflows: CogniFlow.applyWorkflowOp(CogniFlow.sanitizeWorkflows(store.workflows), op) };
          if (op.kind === "exclude-domain" || op.kind === "include-domain") update.excludedDomains = CogniFlow.applyExcludedDomainsOp(store.excludedDomains, op);
          // A private site is scrubbed from folders too, as in the worker.
          if (op.kind === "exclude-domain") update.folders = CogniFlow.applyFolderOp(store.folders, op, Date.now());
          if (store.pendingReturn && !update.workflows.some(workflow => workflow.id === store.pendingReturn.workflowId)) update.pendingReturn = null;
          await window.chrome.storage.local.set(update);
          return { ok: true, result: { workflowCount: update.workflows.length } };
        }
        if (message?.type === "FOLDER_OP") {
          // The same rules the service worker applies, from shared.js.
          const folders = CogniFlow.applyFolderOp(store.folders, message.op, Date.now(), { excludedDomains: store.excludedDomains });
          const update = { folders };
          if (message.op.kind === "save-item") {
            const url = CogniFlow.safeWebUrl(message.op.item?.url);
            const target = folders.find(folder => folder.items.some(item => item.url === url));
            if (target) update.lastFolderId = target.id;
          }
          await window.chrome.storage.local.set(update);
          const saved = update.lastFolderId ? folders.find(folder => folder.id === update.lastFolderId) : null;
          return { ok: true, result: { folderCount: folders.length, folderId: saved?.id || null, folderName: saved?.name || "" } };
        }
        if (message?.type === "CONFIGURE_FLOATING_BUTTON") return { ok: true, result: { registered: store.floatingButtonEnabled } };
        if (message?.type === "TAB_REMINDER_OP") {
          const op = { ...message.op };
          if (op.kind === "remind") {
            const tab = previewTabs.find(item => item.id === op.tabId);
            op.tab = { tabId: tab.id, windowId: 1, url: tab.url, title: tab.title, hostname: new URL(tab.url).hostname };
          }
          const tabWatch = CogniFlow.applyTabReminderOp(store.tabWatch, op, Date.now());
          await window.chrome.storage.local.set({ tabWatch });
          const record = tabWatch.tabs[op.tabId];
          return { ok: true, result: op.kind === "remind" ? { title: record.title, minutes: Math.round((record.waitingUntil - Date.now()) / 60000) } : {} };
        }
        return { ok: true };
      }
    },
    windows: { async getLastFocused() { return { id: 1 }; }, async update() { return { id: 1 }; } },
    tabs: {
      async create() { return { id: Math.floor(Math.random() * 10000) }; },
      async query(filter = {}) { return filter.active ? [previewTabs[0]] : previewTabs; },
      async get(tabId) { const tab = previewTabs.find(item => item.id === tabId); if (!tab) throw new Error("No tab"); return tab; },
      async update() { return { id: 1 }; }
    },
    action: { async setBadgeText() {} }
  };
  window.COGNIFLOW_PREVIEW = true;
})();
