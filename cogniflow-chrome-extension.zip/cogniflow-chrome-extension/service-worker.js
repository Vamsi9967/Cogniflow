importScripts("shared.js");

const { STORAGE_DEFAULTS: DEFAULTS, MAX_WORKFLOWS, REMINDER_MINUTES, TAB_REMINDER_MINUTES } = CogniFlow;
const TAB_CHECK_ALARM = "cogniflow-tab-check";
const PRUNE_ALARM = "cogniflow-prune";
const TAB_NOTIFICATION_PREFIX = "cogniflow-tab-";
const FLOATING_SCRIPT_ID = "cogniflow-floating-button";
const PAGE_ORIGINS = ["http://*/*", "https://*/*"];
// Tab events arrive in bursts (loading, title, favicon); wait for them to settle.
const CAPTURE_DEBOUNCE_MS = 400;

// This worker is the only writer of `workflows`. Every read-modify-write of
// it (tab captures and side panel edits) runs one at a time through this queue.
let storageQueue = Promise.resolve();
const pendingCaptures = new Map();
let idleListenerRegistered = false;
let notificationListenerRegistered = false;

function enqueue(task) {
  const run = storageQueue.then(task);
  storageQueue = run.catch(() => undefined);
  return run;
}

registerIdleMonitoring();
registerNotificationClicks();
void configureReminders();
// On a wake-up this also re-injects into tabs opened before the worker was
// running; the script's own guard makes a second injection a no-op.
configureFloatingButton().catch(error => console.warn("CogniFlow could not set up the in-page button.", error));
void ensureTabCheckAlarm();
// Through the queue, so a sweep can't overwrite a capture that is mid-flight.
enqueue(() => pruneExpiredData()).catch(error => console.warn("CogniFlow could not prune expired data.", error));
void updateBadge();

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const missing = Object.fromEntries(
    Object.entries(DEFAULTS).filter(([key]) => existing[key] === undefined)
  );
  if (Object.keys(missing).length) await chrome.storage.local.set(missing);
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => undefined);
  await configureReminders();
  await ensureTabCheckAlarm();
  await enqueue(() => pruneExpiredData());
});

chrome.tabs.onActivated.addListener(({ windowId, tabId }) => {
  scheduleCapture(windowId, tabId);
  queueTabWatch(() => syncCurrentTab());
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab?.windowId !== undefined && (changeInfo.status === "complete" || changeInfo.title || changeInfo.url)) {
    scheduleCapture(tab.windowId);
  }
  if (changeInfo.title || changeInfo.url) queueTabWatch(() => handleTabUpdate(tabId, tab));
});
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  if (!removeInfo.isWindowClosing) scheduleCapture(removeInfo.windowId);
  queueTabWatch(() => forgetTab(tabId));
});
chrome.windows.onFocusChanged.addListener(windowId => {
  if (windowId !== chrome.windows.WINDOW_ID_NONE) scheduleCapture(windowId);
  // Losing focus to another app also counts as leaving the current tab.
  queueTabWatch(() => syncCurrentTab());
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === TAB_CHECK_ALARM) queueTabWatch(() => checkTabReminders());
  if (alarm.name === PRUNE_ALARM) queueTabWatch(() => pruneExpiredData());
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command !== "remind-current-tab") return;
  enqueue(async () => {
    const tabId = tab?.id ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }).catch(() => []))[0]?.id;
    const state = await chrome.storage.local.get({ tabReminderMinutes: DEFAULTS.tabReminderMinutes });
    const result = await remindAboutTab(tabId, state.tabReminderMinutes);
    await confirmReminderSet(result);
  }).catch(error => showShortcutError(error));
});

// The toolbar badge counts everything waiting for you. It is computed here
// from storage, so nothing else needs to set it.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.blinkToolbarIcon) stopBlinking();
  if (changes.pendingReturn || changes.tabWatch || changes.blinkToolbarIcon) void updateBadge();
});

chrome.permissions.onRemoved.addListener(async removed => {
  const permissions = removed.permissions || [];
  const update = {};
  if (permissions.includes("tabs")) {
    update.trackingEnabled = false;
    update.tabWatch = null;
  }
  if (permissions.includes("idle") || permissions.includes("notifications")) update.idleRemindersEnabled = false;
  // Page access revoked from chrome://extensions, not from our Settings.
  if (permissions.includes("scripting") || (removed.origins || []).length) {
    update.floatingButtonEnabled = false;
    await chrome.storage.local.set({ floatingButtonEnabled: false });
    await configureFloatingButton().catch(() => undefined);
  }
  if (Object.keys(update).length) {
    update.pendingReturn = null;
    update.lastReminderWindowId = null;
    await chrome.storage.local.set(update);
  }
});

chrome.permissions.onAdded.addListener(async added => {
  registerIdleMonitoring();
  registerNotificationClicks();
  if ((added.permissions || []).some(permission => ["idle", "notifications"].includes(permission))) await configureReminders();
  await configureFloatingButton().catch(() => undefined);
});

const messageHandlers = {
  CAPTURE_NOW: message => enqueue(() => captureWindow(message.windowId)),
  WORKFLOW_OP: message => enqueue(() => applyWorkflowOp(message.op)),
  CONFIGURE_REMINDERS: () => {
    registerIdleMonitoring();
    registerNotificationClicks();
    return configureReminders();
  },
  TEST_REMINDER: () => sendNotification(true),
  TAB_REMINDER_OP: message => enqueue(() => applyTabReminderOpFromPanel(message.op)),
  CLEAR_RETURN_HIGHLIGHT: () => clearPendingReturn(),
  FOLDER_OP: message => enqueue(() => applyFolderOpFromPanel(message.op)),
  // From the in-page button. The page supplies no URL: see below.
  PAGE_FOLDER_CONTEXT: (message, sender) => folderContextForTab(sender),
  PAGE_SAVE_TAB: (message, sender) => enqueue(() => saveTabFromPage(message, sender)),
  PAGE_OPEN_PANEL: (message, sender) => openPanelForTab(sender),
  PAGE_REMIND_TAB: (message, sender) => enqueue(() => remindFromPage(sender)),
  CONFIGURE_FLOATING_BUTTON: () => configureFloatingButton()
};

// The in-page button runs in a web page, so it is not the panel and is not
// trusted like it: it may only call the PAGE_ handlers, which take nothing
// from it but a folder choice. Everything that can delete or rewrite saved
// work stays with the extension's own pages.
function senderMayCall(type, sender) {
  if (sender?.id !== chrome.runtime.id) return false;
  const fromPage = Boolean(sender.tab);
  return fromPage ? type.startsWith("PAGE_") : sender.url?.startsWith(chrome.runtime.getURL("")) === true;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handler = messageHandlers[message?.type];
  if (!handler || !senderMayCall(message.type, sender)) return;
  // Called straight away, not from a .then(): chrome.sidePanel.open() is only
  // allowed while the user's click is still in scope, and a deferred call —
  // even by one turn of the microtask queue — can fall outside it.
  let running;
  try { running = Promise.resolve(handler(message, sender)); } catch (error) { running = Promise.reject(error); }
  running
    .then(result => sendResponse({ ok: true, result }))
    .catch(error => sendResponse({ ok: false, error: error?.message || String(error) }));
  return true;
});

async function applyWorkflowOp(op) {
  const state = await chrome.storage.local.get({ workflows: [], excludedDomains: [], pendingReturn: null, tabWatch: null });
  const workflows = CogniFlow.applyWorkflowOp(CogniFlow.sanitizeWorkflows(state.workflows), op);
  const update = { workflows };
  if (op.kind === "exclude-domain" || op.kind === "include-domain") {
    update.excludedDomains = CogniFlow.applyExcludedDomainsOp(state.excludedDomains, op);
  }
  // Private sites and "delete all" apply to watched tabs too.
  if (op.kind === "exclude-domain") update.tabWatch = CogniFlow.applyTabReminderOp(state.tabWatch, { kind: "drop-host", domain: op.domain }, Date.now());
  if (op.kind === "clear-all") update.tabWatch = null;
  // "Delete all saved work" is about what CogniFlow collected on its own.
  // Folders are what you put there by hand, so they have their own control
  // in Settings and are not swept up by this one.
  if (op.kind === "exclude-domain") {
    const stored = await chrome.storage.local.get({ folders: [] });
    update.folders = CogniFlow.applyFolderOp(stored.folders, op, Date.now());
  }
  const pendingId = state.pendingReturn?.workflowId;
  if (pendingId && !workflows.some(workflow => workflow.id === pendingId)) {
    update.pendingReturn = null;
    update.lastReminderWindowId = null;
  }
  await chrome.storage.local.set(update);
  return { workflowCount: workflows.length };
}

// Folders go through the same queue as everything else, so a save made from
// a page cannot land on top of an edit made in the panel.
async function applyFolderOpFromPanel(op) {
  const state = await chrome.storage.local.get({ folders: [], excludedDomains: [], lastFolderId: null });
  const folders = CogniFlow.applyFolderOp(state.folders, op, Date.now(), { excludedDomains: state.excludedDomains });
  const update = { folders };
  if (op.kind === "save-item") {
    const url = CogniFlow.safeWebUrl(op.item?.url);
    const target = folders.find(folder => folder.items.some(item => item.url === url));
    if (target) update.lastFolderId = target.id;
  }
  // The in-page button saves to the last folder used; if that one is gone,
  // it has to ask again rather than pick for you.
  if (op.kind === "delete-folder" && state.lastFolderId === op.folderId) update.lastFolderId = null;
  await chrome.storage.local.set(update);
  const saved = update.lastFolderId ? folders.find(folder => folder.id === update.lastFolderId) : null;
  return { folderCount: folders.length, folderId: saved?.id || null, folderName: saved?.name || "" };
}

// ---- The in-page button ---------------------------------------------------
// It is registered only once the user turns it on and grants page access, and
// unregistered the moment either goes away — so a default install injects
// nothing anywhere. See floating-button.js for what it is allowed to know.

async function floatingButtonAllowed() {
  const state = await chrome.storage.local.get({ floatingButtonEnabled: false });
  if (!state.floatingButtonEnabled) return false;
  // The same patterns the panel requests and the script matches: asking
  // contains() about <all_urls> would not match a grant made for these two.
  return chrome.permissions.contains({ permissions: ["scripting"], origins: PAGE_ORIGINS }).catch(() => false);
}

async function configureFloatingButton() {
  const wanted = await floatingButtonAllowed();
  // chrome.scripting only exists once its optional permission is granted, and
  // a worker that was already running may not have it yet. Say so rather than
  // failing silently, which is what a switch that does nothing looks like.
  if (!chrome.scripting) {
    if (wanted) throw new Error("Chrome has not granted script access yet. Reload the extension on chrome://extensions and try again.");
    return { registered: false, tabs: 0 };
  }
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [FLOATING_SCRIPT_ID] }).catch(() => []);
  if (!wanted) {
    if (registered.length) await chrome.scripting.unregisterContentScripts({ ids: [FLOATING_SCRIPT_ID] }).catch(() => undefined);
    // Registration only governs pages loaded from now on, so the tabs already
    // open still have the button on them until they are told otherwise.
    const removed = await syncOpenTabs(false);
    return { registered: false, tabs: removed };
  }
  if (registered.length) return { registered: true, tabs: await syncOpenTabs(true) };
  await chrome.scripting.registerContentScripts([{
    id: FLOATING_SCRIPT_ID,
    matches: PAGE_ORIGINS,
    // No CSS file: the button carries its own styles inside a closed shadow
    // root, so nothing of ours reaches the page's stylesheet and nothing of
    // the page's reaches the button.

    js: ["floating-button.js"],
    // Top frame only: one button per page, never one per ad iframe.
    allFrames: false,
    runAt: "document_idle",
    persistAcrossSessions: true
  }]).catch(error => {
    // The panel asks for this at the same moment permissions.onAdded does, so
    // the loser of that race finds the script already registered. That is the
    // state we wanted, not a failure.
    if (!/duplicate|already/i.test(error?.message || "")) throw error;
  });
  // The same gap in the other direction: a registered script runs on the next
  // load, so without this the button appears on nothing you already had open,
  // which reads as "I turned it on and nothing happened".
  return { registered: true, tabs: await syncOpenTabs(true) };
}

// Add the button to, or take it from, every ordinary web page already open.
// Chrome refuses injection on its own pages, the Web Store and other
// extensions' pages; those are skipped rather than reported as failures.
async function syncOpenTabs(enable) {
  const tabs = await chrome.tabs.query({ url: PAGE_ORIGINS }).catch(() => []);
  const results = await Promise.all(tabs.map(async tab => {
    if (!Number.isInteger(tab.id)) return false;
    try {
      if (enable) await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["floating-button.js"] });
      else await chrome.tabs.sendMessage(tab.id, { type: "COGNIFLOW_UNMOUNT" });
      return true;
    } catch {
      // A page Chrome will not let an extension touch, or one with no script
      // in it to talk to. Neither is a problem worth stopping for.
      return false;
    }
  }));
  return results.filter(Boolean).length;
}

// What the button is told. Not the page's content, and not a list of
// everything saved — just the folder names it needs to draw, and whether
// this page is already in one.
async function folderContextForTab(sender) {
  const url = CogniFlow.safeWebUrl(sender?.tab?.url);
  if (!url || !await floatingButtonAllowed()) return { enabled: false, folders: [] };
  const state = await chrome.storage.local.get({ folders: [], excludedDomains: [], lastFolderId: null });
  const folders = CogniFlow.sanitizeFolders(state.folders);
  const hostname = CogniFlow.hostOf(url);
  if (CogniFlow.isExcludedHost(hostname, state.excludedDomains || [])) return { enabled: false, folders: [], excluded: true };
  const settings = await chrome.storage.local.get({ tabReminderMinutes: DEFAULTS.tabReminderMinutes, floatingButtonOffset: 0.5 });
  return {
    enabled: true,
    lastFolderId: state.lastFolderId,
    reminderMinutes: settings.tabReminderMinutes,
    offset: settings.floatingButtonOffset,
    savedIn: folders.filter(folder => folder.items.some(item => item.url === url)).map(folder => folder.id),
    folders: folders.map(folder => ({ id: folder.id, name: folder.name, count: folder.items.length }))
  };
}

// The page asks to save "this tab" and says nothing about which tab that is.
// The URL and title come from sender.tab, which Chrome fills in and a page
// cannot forge, so a hostile page can add itself to a folder at worst — the
// same thing the button in front of the user does.
async function saveTabFromPage(message, sender) {
  if (!sender?.tab || !await floatingButtonAllowed()) throw new Error("The in-page button is turned off.");
  const url = CogniFlow.safeWebUrl(sender.tab.url);
  if (!url) throw new Error("This page cannot be saved.");
  return applyFolderOpFromPanel({
    kind: "save-item",
    folderId: message.folderId,
    folderName: message.folderName,
    item: { url, title: sender.tab.title || "", hostname: CogniFlow.hostOf(url) }
  });
}

// Opening the panel from the in-page button.
//
// sidePanel.open() needs live user activation. Chrome passes the activation
// from a content script's click along with the message, but only as far as
// the first await: a storage read or a permissions check before the call
// spends it, and Chrome then refuses. So this is the first thing that runs,
// synchronously, and the checks come after. Nothing is risked by that order —
// the sender was already verified as this extension, and the worst a stray
// call can do is open our own panel.
//
// tabId is preferred over windowId: it opens the panel for the tab the click
// came from, which is also the narrower grant of the two.
function openPanelForTab(sender) {
  const tab = sender?.tab;
  if (!tab) throw new Error("The in-page button is turned off.");
  const target = Number.isInteger(tab.id) ? { tabId: tab.id } : { windowId: tab.windowId };
  return chrome.sidePanel.open(target)
    .then(() => ({ opened: true }))
    // Whatever Chrome says, say it. Replacing the message with a guess is
    // how the real reason stayed hidden the first time round.
    .catch(error => { throw new Error(error?.message || "Chrome would not open the panel."); });
}

// The same reminder the keyboard shortcut sets, for the tab the click came
// from. As with saving, the page says nothing about which tab that is.
async function remindFromPage(sender) {
  if (!sender?.tab || !await floatingButtonAllowed()) throw new Error("The in-page button is turned off.");
  const state = await chrome.storage.local.get({ tabReminderMinutes: DEFAULTS.tabReminderMinutes });
  return remindAboutTab(sender.tab.id, state.tabReminderMinutes);
}

async function clearPendingReturn() {
  await chrome.storage.local.set({ pendingReturn: null, lastReminderWindowId: null });
}

function registerIdleMonitoring() {
  if (idleListenerRegistered || !chrome.idle?.onStateChanged) return;
  chrome.idle.onStateChanged.addListener(newState => {
    // Locking the screen can go straight from "active" to "locked", skipping "idle".
    // Queued so "idle" is stored before "active" reads it, and so neither
    // races a side panel edit to pendingReturn.
    const task = newState === "active" ? () => notifyOnReturn() : () => rememberIdleContext(newState);
    enqueue(task).catch(error => console.warn("CogniFlow idle handling failed.", error));
  });
  idleListenerRegistered = true;
}

function registerNotificationClicks() {
  if (notificationListenerRegistered || !chrome.notifications?.onClicked) return;
  chrome.notifications.onClicked.addListener(async notificationId => {
    if (notificationId.startsWith(TAB_NOTIFICATION_PREFIX)) {
      await goToWatchedTab(Number(notificationId.slice(TAB_NOTIFICATION_PREFIX.length)));
      await chrome.notifications.clear(notificationId).catch(() => undefined);
      return;
    }
    if (notificationId !== "cogniflow-idle-reminder") return;
    const { lastReminderWindowId } = await chrome.storage.local.get("lastReminderWindowId");
    // The saved window may have been closed since the reminder was created.
    const savedWindow = Number.isInteger(lastReminderWindowId)
      ? await chrome.windows.get(lastReminderWindowId).catch(() => null)
      : null;
    const windowId = savedWindow?.id ?? (await chrome.windows.getLastFocused().catch(() => null))?.id;
    if (Number.isInteger(windowId)) {
      await chrome.windows.update(windowId, { focused: true }).catch(() => undefined);
      await chrome.sidePanel.open({ windowId }).catch(() => undefined);
    }
    await chrome.notifications.clear(notificationId).catch(() => undefined);
  });
  chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    if (!notificationId.startsWith(TAB_NOTIFICATION_PREFIX)) return;
    const tabId = Number(notificationId.slice(TAB_NOTIFICATION_PREFIX.length));
    const kind = buttonIndex === 0 ? "snooze" : "done";
    queueTabWatch(async () => {
      await applyTabReminderOpFromPanel({ kind, tabId });
      await chrome.notifications.clear(notificationId).catch(() => undefined);
    });
  });
  notificationListenerRegistered = true;
}

async function configureReminders() {
  const state = await chrome.storage.local.get(DEFAULTS);
  if (!state.idleRemindersEnabled || !chrome.idle) return;
  const granted = await chrome.permissions.contains({ permissions: ["idle", "notifications"] });
  if (!granted) return;
  const minutes = REMINDER_MINUTES.includes(Number(state.reminderMinutes)) ? Number(state.reminderMinutes) : DEFAULTS.reminderMinutes;
  chrome.idle.setDetectionInterval(minutes * 60);
  registerIdleMonitoring();
  registerNotificationClicks();
}

async function rememberIdleContext(idleState = "idle") {
  const state = await chrome.storage.local.get(DEFAULTS);
  const workflows = CogniFlow.sanitizeWorkflows(state.workflows).filter(item => Number.isFinite(item.lastActive));
  if (!state.trackingEnabled || !state.idleRemindersEnabled || !workflows.length) return;
  // "idle" then "locked" can both fire for one absence; keep the first start time.
  if (idleState === "locked" && state.pendingReturn && !state.pendingReturn.notifiedAt) return;
  if (!await chrome.permissions.contains({ permissions: ["idle", "notifications"] })) return;
  const now = Date.now();
  const workflow = [...workflows].sort((a, b) => b.lastActive - a.lastActive)[0];
  if (!workflow?.lastActive || now - workflow.lastActive > 3 * 60 * 60 * 1000) return;
  await chrome.storage.local.set({
    pendingReturn: {
      workflowId: workflow.id,
      windowId: workflow.windowId,
      idleStartedAt: now,
      notifiedAt: null
    }
  });
}

async function notifyOnReturn() {
  const state = await chrome.storage.local.get({ ...DEFAULTS, pendingReturn: null });
  const pending = state.pendingReturn;
  if (!state.trackingEnabled || !state.idleRemindersEnabled || !pending || pending.notifiedAt) return;
  if (!await chrome.permissions.contains({ permissions: ["idle", "notifications"] })) return;
  const workflow = CogniFlow.sanitizeWorkflows(state.workflows).find(item => item.id === pending.workflowId);
  if (!workflow) {
    await chrome.storage.local.set({ pendingReturn: null, lastReminderWindowId: null });
    return;
  }
  try {
    await sendNotification(false, workflow, state.showTabTitleInReturnAlert);
  } catch (error) {
    console.warn("CogniFlow could not display the return notification.", error);
    return;
  }
  const notifiedAt = Date.now();
  await chrome.storage.local.set({ pendingReturn: { ...pending, notifiedAt }, lastReminderWindowId: pending.windowId ?? null });
  await blinkToolbar(NEW_ALERT_BLINK_MS);
}

async function sendNotification(isTest, workflow, includeTitle = true) {
  if (!chrome.notifications) throw new Error("Notification permission is not available.");
  const hasPermission = await chrome.permissions.contains({ permissions: ["notifications"] });
  if (!hasPermission) throw new Error("Allow CogniFlow notifications in Chrome, then try again.");
  const activeTab = workflow?.tabs?.find(tab => tab.url === workflow.activeUrl);
  const lastTab = includeTitle && (workflow?.activeTitle || activeTab?.title)
    ? `You paused in “${workflow.activeTitle || activeTab.title}”${activeTab?.hostname ? ` on ${activeTab.hostname}` : ""}. `
    : "Your last browser work is saved on this device. ";
  await chrome.notifications.create("cogniflow-idle-reminder", {
    type: "basic",
    iconUrl: chrome.runtime.getURL("notification-icon.png"),
    title: isTest ? "CogniFlow reminder is on" : "Welcome back",
    message: isTest
      ? "This is a test reminder. CogniFlow will notify you when you return after your chosen idle period."
      : `${lastTab}Open CogniFlow to continue.`,
    silent: true,
    priority: 0
  });
}

function scheduleCapture(windowId, activeTabId = null) {
  if (!Number.isInteger(windowId)) return;
  const pending = pendingCaptures.get(windowId);
  if (pending) clearTimeout(pending.timer);
  // Keep the tab id from onActivated even if later events in the burst lack one.
  const tabId = Number.isInteger(activeTabId) ? activeTabId : pending?.activeTabId ?? null;
  const timer = setTimeout(() => {
    pendingCaptures.delete(windowId);
    enqueue(() => captureWindow(windowId, tabId)).catch(error => console.warn("CogniFlow capture failed.", error));
  }, CAPTURE_DEBOUNCE_MS);
  pendingCaptures.set(windowId, { timer, activeTabId: tabId });
}

async function captureWindow(windowId, activeTabId = null) {
  const state = await chrome.storage.local.get(DEFAULTS);
  if (!state.trackingEnabled || !state.onboardingComplete) return { skipped: "paused" };

  const hasTabsPermission = await chrome.permissions.contains({ permissions: ["tabs"] });
  if (!hasTabsPermission) return { skipped: "permission-revoked" };

  const win = Number.isInteger(windowId) && windowId !== chrome.windows.WINDOW_ID_NONE
    ? await chrome.windows.get(windowId).catch(() => null)
    : await chrome.windows.getLastFocused().catch(() => null);
  if (!win?.id || win.type !== "normal") return { skipped: "no-window" };
  // If the user allows the extension in incognito, still never save private windows.
  if (win.incognito) return { skipped: "incognito" };

  const tabs = await chrome.tabs.query({ windowId: win.id });
  const excluded = (Array.isArray(state.excludedDomains) ? state.excludedDomains : []).map(CogniFlow.normalizeDomain).filter(Boolean);
  // Time already spent in each tab, from the reminder tracker. It is what
  // tells a workflow apart from the tabs that merely sat in the same window.
  const watch = CogniFlow.sanitizeTabWatch(state.tabWatch);
  const dwellFor = tabId => {
    const record = watch.tabs[tabId];
    if (!record) return 0;
    // The tab on screen right now has time that has not been banked yet.
    const inProgress = watch.current?.tabId === tabId
      ? Math.min(Math.max(0, Date.now() - watch.current.since), CogniFlow.MAX_DWELL_SEGMENT_MS)
      : 0;
    return (record.engagedMs || 0) + inProgress;
  };
  const safeTabs = tabs
    .filter(tab => tab.url && /^https?:\/\//i.test(tab.url))
    .map(tab => {
      let parsed;
      try { parsed = new URL(tab.url); } catch { return null; }
      const hostname = CogniFlow.normalizeDomain(parsed.hostname);
      if (CogniFlow.isExcludedHost(hostname, excluded)) return null;
      return {
        tabId: tab.id,
        openerTabId: tab.openerTabId,
        url: tab.url,
        title: (tab.title || hostname).slice(0, 180),
        hostname,
        active: Boolean(tab.active),
        activeMs: dwellFor(tab.id),
        lastSeen: Date.now()
      };
    })
    .filter(Boolean);

  // Which tab each tab was opened from. Chrome reports this as `openerTabId`
  // whenever you follow a link into a new tab, and it is the only honest
  // statement of relatedness available without reading any page. The lookup
  // is built from eligible tabs ONLY, so an excluded or non-web opener leaves
  // no link rather than writing its URL into a tab that is kept.
  const urlOfTabId = new Map(safeTabs.map(tab => [tab.tabId, tab.url]));
  for (const tab of safeTabs) {
    const openerUrl = Number.isInteger(tab.openerTabId) ? urlOfTabId.get(tab.openerTabId) : undefined;
    tab.openedFrom = openerUrl && openerUrl !== tab.url ? openerUrl : null;
    delete tab.openerTabId;
  }
  if (!safeTabs.length) return { skipped: "no-eligible-tabs" };

  const active = (Number.isInteger(activeTabId) && safeTabs.find(tab => tab.tabId === activeTabId))
    || safeTabs.find(tab => tab.active)
    || safeTabs[0];
  const now = Date.now();
  const workflows = CogniFlow.sanitizeWorkflows(state.workflows);
  // The most recent workflow for this window, if this capture still belongs
  // to it. A long pause or most of the tabs being swapped out means it does not.
  const latest = workflows.find(item => item.windowId === win.id);
  const current = CogniFlow.workflowContinues(latest, safeTabs.map(tab => tab.url), now) ? latest : null;
  const workflow = current || {
    id: crypto.randomUUID(),
    title: cleanTitle(active.title, active.hostname),
    createdAt: now,
    tabs: [],
    windowId: win.id
  };
  // Merge rather than replace: a tab you closed stays in the record, marked
  // closed, so the panel can show you what you shut and let you reopen it.
  const openTabs = safeTabs.map(({ tabId: _tabId, ...tabData }) => ({ ...tabData, active: tabData.url === active.url }));
  // Excluding a site has to drop tabs already held, or a newly private domain
  // would survive here as a closed tab that capture keeps carrying forward.
  const remembered = (workflow.tabs || [])
    .filter(tab => !CogniFlow.isExcludedHost(tab.hostname, excluded))
    // A link pointing at a site that has since become private has to go too,
    // or that URL would survive here as someone else's `openedFrom`.
    .map(tab => (tab.openedFrom && CogniFlow.isExcludedHost(CogniFlow.hostOf(tab.openedFrom), excluded) ? { ...tab, openedFrom: null } : tab));
  workflow.tabs = CogniFlow.mergeWorkflowTabs(remembered, openTabs, now);
  // Name the workflow after the tab you actually worked in. The last active
  // tab is where you happened to be standing when the capture ran, which is
  // why the old title changed every few seconds and described one tab of many.
  const anchor = CogniFlow.workflowAnchor(workflow.tabs, active.url) || active;
  workflow.title = cleanTitle(anchor.title, anchor.hostname) || workflow.title;
  workflow.anchorUrl = anchor.url;
  workflow.lastActive = now;
  workflow.activeUrl = active.url;
  workflow.activeTitle = active.title;
  // What was open, not what is remembered; the panel counts closed tabs apart.
  workflow.tabCount = openTabs.length;

  const index = workflows.findIndex(item => item.id === workflow.id);
  if (index >= 0) workflows.splice(index, 1);
  workflows.unshift(workflow);
  await chrome.storage.local.set({ workflows: workflows.slice(0, MAX_WORKFLOWS) });
  return { workflowId: workflow.id, tabCount: safeTabs.length };
}

function cleanTitle(title, fallback) {
  return (title || fallback || "Current work")
    .replace(/\s+[—|·-]\s+(Google Chrome|Mozilla Firefox|Microsoft Edge)$/i, "")
    .slice(0, 80);
}

// ---- Forgotten-tab reminders ----------------------------------------------
// Three signals, all from tab metadata (never page content):
//   1. "waiting"   you asked to be reminded about a tab (shortcut or panel)
//   2. "forgotten" you worked on a tab, left it open and haven't been back
//   3. "changed"   a tab you worked on changed its title after you left,
//                  which is how AI chats and inboxes signal something new
// State lives in `tabWatch` (see shared.js) and is only written in the queue.

function queueTabWatch(task) {
  enqueue(task).catch(error => console.warn("CogniFlow tab reminder update failed.", error));
}

async function ensureTabCheckAlarm() {
  if (!chrome.alarms) return;
  const existing = await chrome.alarms.get(TAB_CHECK_ALARM).catch(() => null);
  if (!existing) await chrome.alarms.create(TAB_CHECK_ALARM, { periodInMinutes: 1 });
  // Expiry has to happen even when nothing is being browsed, so it runs on
  // its own schedule rather than only when tabs change.
  const prune = await chrome.alarms.get(PRUNE_ALARM).catch(() => null);
  if (!prune) await chrome.alarms.create(PRUNE_ALARM, { periodInMinutes: 30 });
}

// Deletes everything past the 24-hour retention window. The sanitize helpers
// already hide expired entries from every reader; this is what actually
// removes them from disk, so nothing lingers in storage after it is shown.
// Folders are deliberately absent from this sweep. Everything CogniFlow
// collected by itself expires; what you filed by hand is yours until you
// delete it.
async function pruneExpiredData() {
  const stored = await chrome.storage.local.get({ workflows: [], tabWatch: null, pendingReturn: null });
  const now = Date.now();
  const update = {};

  const workflows = CogniFlow.sanitizeWorkflows(stored.workflows, now);
  const storedCount = Array.isArray(stored.workflows) ? stored.workflows.length : 0;
  if (workflows.length !== storedCount) update.workflows = workflows;

  if (stored.tabWatch) {
    const watch = CogniFlow.sanitizeTabWatch(stored.tabWatch, now);
    const before = Object.keys(stored.tabWatch.tabs || {}).length;
    if (Object.keys(watch.tabs).length !== before) update.tabWatch = watch;
  }

  // A return alert pointing at work that just expired has nothing to show.
  const pendingId = stored.pendingReturn?.workflowId;
  if (pendingId && !workflows.some(workflow => workflow.id === pendingId)) {
    update.pendingReturn = null;
    update.lastReminderWindowId = null;
  }

  if (Object.keys(update).length) await chrome.storage.local.set(update);
  return { workflows: workflows.length };
}

// Reads what's needed and returns null when watching isn't allowed.
async function loadTabWatch() {
  const state = await chrome.storage.local.get({
    trackingEnabled: false, onboardingComplete: false, excludedDomains: [], tabWatch: null,
    tabRemindersEnabled: false, tabReminderMinutes: DEFAULTS.tabReminderMinutes, showTabTitleInReturnAlert: true
  });
  if (!state.trackingEnabled || !state.onboardingComplete) return null;
  if (!await chrome.permissions.contains({ permissions: ["tabs"] })) return null;
  return { ...state, watch: CogniFlow.sanitizeTabWatch(state.tabWatch) };
}

function saveTabWatch(watch) {
  // Keep storage small: drop the longest-untouched records past the cap.
  const records = Object.values(watch.tabs);
  if (records.length > CogniFlow.MAX_WATCHED_TABS) {
    records
      .filter(record => record.tabId !== watch.current?.tabId && !record.needsAttention && !Number.isFinite(record.waitingUntil))
      .sort((a, b) => (a.leftAt || a.firstSeen) - (b.leftAt || b.firstSeen))
      .slice(0, records.length - CogniFlow.MAX_WATCHED_TABS)
      .forEach(record => delete watch.tabs[record.tabId]);
  }
  return chrome.storage.local.set({ tabWatch: watch });
}

// The tab fields CogniFlow keeps, or null for pages it must not watch.
function watchableTab(tab, excludedDomains) {
  if (!tab || !Number.isInteger(tab.id) || tab.incognito) return null;
  const url = CogniFlow.safeWebUrl(tab.url);
  if (!url) return null;
  const hostname = CogniFlow.normalizeDomain(new URL(url).hostname);
  const excluded = (Array.isArray(excludedDomains) ? excludedDomains : []).map(CogniFlow.normalizeDomain).filter(Boolean);
  if (CogniFlow.isExcludedHost(hostname, excluded)) return null;
  return { tabId: tab.id, windowId: tab.windowId, url, hostname, title: (tab.title || hostname).slice(0, 180) };
}

function closeVisit(record, current, now) {
  if (!record || !current) return;
  const visitMs = Math.min(Math.max(0, now - current.since), CogniFlow.MAX_DWELL_SEGMENT_MS);
  record.engagedMs = (record.engagedMs || 0) + visitMs;
  record.leftAt = now;
}

// "Current" = the active tab of the focused Chrome window, or nothing when
// another app has focus. Switching it closes the previous tab's visit.
async function syncCurrentTab() {
  const loaded = await loadTabWatch();
  if (!loaded) return;
  const { watch } = loaded;
  const now = Date.now();
  const win = await chrome.windows.getLastFocused().catch(() => null);
  const [tab] = win?.focused && win.type === "normal"
    ? await chrome.tabs.query({ active: true, windowId: win.id }).catch(() => [])
    : [];
  const info = watchableTab(tab, loaded.excludedDomains);
  const previous = watch.current;
  const previousRecord = previous && watch.tabs[previous.tabId];

  if (previous && info && previous.tabId === info.tabId) {
    // Same tab. If it moved to another site, that's a new piece of work.
    if (previousRecord && previousRecord.hostname !== info.hostname) {
      Object.assign(previousRecord, CogniFlow.newTabRecord(info, now));
      watch.current = { tabId: info.tabId, since: now };
    } else if (previousRecord) {
      Object.assign(previousRecord, { url: info.url, title: info.title });
    } else {
      watch.tabs[info.tabId] = CogniFlow.newTabRecord(info, now);
    }
  } else {
    closeVisit(previousRecord, previous, now);
    if (info) {
      const existing = watch.tabs[info.tabId];
      const sameSite = existing && existing.hostname === info.hostname;
      // Coming back to a tab answers every reminder about it.
      watch.tabs[info.tabId] = {
        ...(sameSite ? existing : CogniFlow.newTabRecord(info, now)),
        url: info.url, title: info.title, windowId: info.windowId,
        leftAt: null, titleChangedAt: null, waitingUntil: null, needsAttention: false, reason: null, nudgedAt: null, doneAt: null
      };
      watch.current = { tabId: info.tabId, since: now };
      if (chrome.notifications) await chrome.notifications.clear(`${TAB_NOTIFICATION_PREFIX}${info.tabId}`).catch(() => undefined);
    } else {
      watch.current = null;
    }
  }
  // The tab moved to a page CogniFlow doesn't watch (chrome://, a private site).
  if (tab && !info && Number.isInteger(tab.id)) delete watch.tabs[tab.id];
  await saveTabWatch(watch);
}

async function handleTabUpdate(tabId, tab) {
  const loaded = await loadTabWatch();
  if (!loaded) return;
  const { watch } = loaded;
  if (watch.current?.tabId === tabId) return syncCurrentTab();
  const record = watch.tabs[tabId];
  if (!record) return;
  const info = watchableTab(tab, loaded.excludedDomains);
  if (!info || info.hostname !== record.hostname) {
    // A background tab that went to another site is no longer the work you left.
    delete watch.tabs[tabId];
    return saveTabWatch(watch);
  }
  const now = Date.now();
  const titleChanged = info.title !== record.title;
  Object.assign(record, { url: info.url, title: info.title });
  if (titleChanged && Number.isFinite(record.leftAt) && now - record.leftAt >= 5000) record.titleChangedAt = now;
  await saveTabWatch(watch);
}

async function forgetTab(tabId) {
  const stored = await chrome.storage.local.get({ tabWatch: null });
  const watch = CogniFlow.sanitizeTabWatch(stored.tabWatch);
  if (!watch.tabs[tabId] && watch.current?.tabId !== tabId) return;
  delete watch.tabs[tabId];
  if (watch.current?.tabId === tabId) watch.current = null;
  await saveTabWatch(watch);
  if (chrome.notifications) await chrome.notifications.clear(`${TAB_NOTIFICATION_PREFIX}${tabId}`).catch(() => undefined);
}

async function isUserActive() {
  // With the idle permission (granted for return alerts) skip reminders while
  // you're away; without it, assume you're here.
  if (!chrome.idle?.queryState) return true;
  if (!await chrome.permissions.contains({ permissions: ["idle"] })) return true;
  return (await chrome.idle.queryState(60).catch(() => "active")) === "active";
}

// Runs every minute from an alarm.
async function checkTabReminders() {
  const loaded = await loadTabWatch();
  if (!loaded) return;
  const { watch } = loaded;
  const now = Date.now();
  let changed = false;
  let newAlert = false;

  // Drop records for tabs that closed while the worker was asleep, and
  // records left over from a previous browser session (tab ids are reused).
  const openTabs = new Map((await chrome.tabs.query({}).catch(() => [])).map(tab => [tab.id, tab]));
  for (const record of Object.values(watch.tabs)) {
    const open = openTabs.get(record.tabId);
    if (!open || CogniFlow.safeWebUrl(open.url) === "" || CogniFlow.normalizeDomain(new URL(open.url).hostname) !== record.hostname) {
      delete watch.tabs[record.tabId];
      changed = true;
    }
  }
  if (watch.current && !watch.tabs[watch.current.tabId]) { watch.current = null; changed = true; }

  // A reminder that came due while you were on the tab is already answered.
  const currentRecord = watch.current && watch.tabs[watch.current.tabId];
  if (currentRecord && Number.isFinite(currentRecord.waitingUntil) && currentRecord.waitingUntil <= now) {
    currentRecord.waitingUntil = null;
    changed = true;
  }

  if (await isUserActive()) {
    const minutes = TAB_REMINDER_MINUTES.includes(Number(loaded.tabReminderMinutes)) ? Number(loaded.tabReminderMinutes) : DEFAULTS.tabReminderMinutes;
    const due = CogniFlow.dueTabReminders(watch, now, { autoEnabled: loaded.tabRemindersEnabled, forgottenMs: minutes * 60 * 1000 });
    const autoAllowed = now - watch.lastNudgeAt >= CogniFlow.AUTO_NUDGE_GAP_MS;
    // Reminders you set always fire; automatic ones are spaced out. One per check.
    const pick = due.find(item => item.reason === "waiting" || autoAllowed);
    newAlert = Boolean(pick);
    if (pick) {
      Object.assign(pick.record, { needsAttention: true, reason: pick.reason, nudgedAt: now, waitingUntil: null });
      if (pick.reason !== "waiting") watch.lastNudgeAt = now;
      changed = true;
      await sendTabReminder(pick.record, pick.reason, loaded.showTabTitleInReturnAlert).catch(error => console.warn("CogniFlow could not show a tab reminder.", error));
    }
  }
  if (changed) await saveTabWatch(watch);
  // A new alert blinks; older unanswered ones pulse once a minute (this check's cadence).
  if (await isUserActive()) await blinkToolbar(newAlert ? NEW_ALERT_BLINK_MS : REMINDER_PULSE_MS);
}

function minutesAgo(time) {
  const minutes = Math.max(1, Math.round((Date.now() - time) / 60000));
  return `${minutes} min ago`;
}

async function sendTabReminder(record, reason, includeTitle) {
  // Without notification permission the badge and the panel still show it.
  if (!chrome.notifications || !await chrome.permissions.contains({ permissions: ["notifications"] })) return;
  const site = record.hostname.replace(/^www\./, "");
  const page = includeTitle ? `“${record.title}”` : "A tab";
  const note = includeTitle && record.note ? ` Note: ${record.note}` : "";
  const copy = {
    waiting: { title: `Reminder: ${site}`, message: `${page} — you asked to come back to this.` },
    changed: { title: `${site} may be ready`, message: `${page} changed after you left it ${minutesAgo(record.leftAt)}.` },
    forgotten: { title: `Still open: ${site}`, message: `${page} — you worked on this and left it ${minutesAgo(record.leftAt)}.` }
  }[reason];
  await chrome.notifications.create(`${TAB_NOTIFICATION_PREFIX}${record.tabId}`, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("notification-icon.png"),
    title: copy.title,
    message: `${copy.message}${note} Click to go back.`,
    buttons: [{ title: "Snooze 10 min" }, { title: "Done" }],
    priority: 1
  });
}

// "Remind me about this tab", from the shortcut or the panel.
async function remindAboutTab(tabId, minutes) {
  const loaded = await loadTabWatch();
  if (!loaded) throw new Error("Turn on memory in CogniFlow first.");
  const tab = Number.isInteger(tabId) ? await chrome.tabs.get(tabId).catch(() => null) : null;
  const info = watchableTab(tab, loaded.excludedDomains);
  if (!info) throw new Error("CogniFlow can only remind you about regular web pages that aren't private sites.");
  const watch = CogniFlow.applyTabReminderOp(loaded.watch, { kind: "remind", tab: info, minutes }, Date.now());
  await saveTabWatch(watch);
  return { title: info.title, minutes: Math.round((watch.tabs[info.tabId].waitingUntil - Date.now()) / 60000) };
}

async function applyTabReminderOpFromPanel(op) {
  if (op?.kind === "remind") return remindAboutTab(op.tabId, op.minutes);
  const stored = await chrome.storage.local.get({ tabWatch: null });
  await saveTabWatch(CogniFlow.applyTabReminderOp(stored.tabWatch, op, Date.now()));
  if (chrome.notifications && Number.isInteger(op?.tabId)) await chrome.notifications.clear(`${TAB_NOTIFICATION_PREFIX}${op.tabId}`).catch(() => undefined);
  return {};
}

async function confirmReminderSet({ title, minutes }) {
  if (!chrome.notifications || !await chrome.permissions.contains({ permissions: ["notifications"] })) return;
  await chrome.notifications.create("cogniflow-reminder-set", {
    type: "basic",
    iconUrl: chrome.runtime.getURL("notification-icon.png"),
    title: "Reminder set",
    message: `CogniFlow will remind you about “${title}” in ${minutes} min, unless you go back to it first.`,
    silent: true,
    priority: 0
  });
}

async function showShortcutError(error) {
  console.warn("CogniFlow could not set a reminder.", error);
  if (!chrome.notifications || !await chrome.permissions.contains({ permissions: ["notifications"] }).catch(() => false)) return;
  await chrome.notifications.create("cogniflow-reminder-set", {
    type: "basic",
    iconUrl: chrome.runtime.getURL("notification-icon.png"),
    title: "Couldn't set a reminder",
    message: error?.message || "Try again from the CogniFlow panel.",
    silent: true,
    priority: 0
  }).catch(() => undefined);
}

async function goToWatchedTab(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab) {
    await chrome.tabs.update(tabId, { active: true }).catch(() => undefined);
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => undefined);
    return;
  }
  // The tab closed after the reminder; reopen its page.
  const { tabWatch } = await chrome.storage.local.get({ tabWatch: null });
  const url = CogniFlow.safeWebUrl(CogniFlow.sanitizeTabWatch(tabWatch).tabs[tabId]?.url);
  if (url) await chrome.tabs.create({ url, active: true }).catch(() => undefined);
}

// ---- Toolbar alert: badge + blinking icon ----------------------------------
// When something needs you (a tab reminder or "welcome back"), the badge shows
// the count and the icon turns orange. A new alert blinks the icon for a few
// seconds, and it pulses briefly every minute until you deal with it.
const NORMAL_ICON = Object.freeze({ 16: "extension-icon-16.png", 32: "extension-icon-32.png" });
const ALERT_COLOR = [234, 88, 12]; // #ea580c
const BLINK_STEP_MS = 600;
const NEW_ALERT_BLINK_MS = 12 * 1000;
const REMINDER_PULSE_MS = 3 * 1000;
let alertIconPromise = null;
let blinkTimer = null;
let blinkUntil = 0;
let blinkPhase = false;

// The same icon with its blue background swapped for orange. Each pixel is
// mixed toward orange by how blue it is, so the white mark and its
// anti-aliased edges stay clean.
function buildAlertIcon() {
  alertIconPromise ||= (async () => {
    const imageData = {};
    for (const [size, path] of Object.entries(NORMAL_ICON)) {
      const blob = await (await fetch(chrome.runtime.getURL(path))).blob();
      const bitmap = await createImageBitmap(blob);
      const canvas = new OffscreenCanvas(Number(size), Number(size));
      const context = canvas.getContext("2d");
      context.drawImage(bitmap, 0, 0, Number(size), Number(size));
      const pixels = context.getImageData(0, 0, Number(size), Number(size));
      const data = pixels.data;
      for (let i = 0; i < data.length; i += 4) {
        const blueness = Math.min(1, Math.max(0, (data[i + 2] - data[i]) / 198));
        for (let channel = 0; channel < 3; channel += 1) {
          data[i + channel] = Math.round(data[i + channel] * (1 - blueness) + ALERT_COLOR[channel] * blueness);
        }
      }
      imageData[size] = pixels;
    }
    return imageData;
  })().catch(error => {
    alertIconPromise = null;
    throw error;
  });
  return alertIconPromise;
}

async function setToolbarLook(alert) {
  if (!chrome.action) return;
  if (alert) {
    const imageData = await buildAlertIcon().catch(() => null);
    if (imageData) await chrome.action.setIcon({ imageData }).catch(() => undefined);
  } else {
    await chrome.action.setIcon({ path: NORMAL_ICON }).catch(() => undefined);
  }
  await chrome.action.setBadgeBackgroundColor({ color: alert ? "#ea580c" : "#2563eb" }).catch(() => undefined);
}

async function attentionCount() {
  const { pendingReturn, tabWatch } = await chrome.storage.local.get({ pendingReturn: null, tabWatch: null });
  const flaggedTabs = Object.values(CogniFlow.sanitizeTabWatch(tabWatch).tabs).filter(record => record.needsAttention).length;
  return flaggedTabs + (pendingReturn?.notifiedAt ? 1 : 0);
}

function stopBlinking() {
  clearInterval(blinkTimer);
  blinkTimer = null;
  blinkUntil = 0;
}

// Blink for at least `durationMs`. Each step is a Chrome API call, which also
// keeps this worker alive until the blinking ends.
async function blinkToolbar(durationMs) {
  if (!chrome.action) return;
  const { blinkToolbarIcon } = await chrome.storage.local.get({ blinkToolbarIcon: DEFAULTS.blinkToolbarIcon });
  if (!blinkToolbarIcon || !await attentionCount()) return;
  blinkUntil = Math.max(blinkUntil, Date.now() + durationMs);
  if (blinkTimer) return;
  blinkPhase = false;
  blinkTimer = setInterval(() => {
    if (Date.now() >= blinkUntil) {
      stopBlinking();
      void updateBadge();
      return;
    }
    blinkPhase = !blinkPhase;
    // Alternate the orange alert look with the normal blue icon.
    void setToolbarLook(!blinkPhase);
  }, BLINK_STEP_MS);
}

async function updateBadge() {
  if (!chrome.action) return;
  const count = await attentionCount();
  const { blinkToolbarIcon } = await chrome.storage.local.get({ blinkToolbarIcon: DEFAULTS.blinkToolbarIcon });
  await chrome.action.setBadgeTextColor?.({ color: "#ffffff" }).catch(() => undefined);
  await chrome.action.setBadgeText({ text: count ? String(count) : "" }).catch(() => undefined);
  if (!count) stopBlinking();
  // While blinking, the blink loop owns the icon; it restores this look when done.
  if (!blinkTimer) await setToolbarLook(count > 0 && blinkToolbarIcon);
}
