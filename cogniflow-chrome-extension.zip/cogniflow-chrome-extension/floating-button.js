// The in-page button: a small launcher docked to the right edge of every page
// you visit. Click it and a stack of actions opens — file this tab into a
// folder, start a new folder, set a reminder, or open the panel.
//
// The pattern is the one Acrobat uses: a collapsed pill that grows upward into
// labelled rows, and which you drag to move. The skin is CogniFlow's own — the
// panel's surfaces, line, radii, type scale and blue — because a widget that
// looked like another product's would be the one piece of this extension that
// does not belong to it.
//
// This is the only part of CogniFlow that runs inside a web page, so it is
// written to be able to do as little as possible there:
//
//   * It never reads the page. It does not touch document.title, location,
//     cookies, storage or any element outside its own shadow root. Picking a
//     folder sends { folderId } and nothing else; the service worker takes the
//     URL and title from sender.tab, which Chrome fills in and a page cannot
//     forge. The same is true of the reminder.
//   * It lives in a closed shadow root, so the page cannot style it, read it
//     or click it on your behalf, and its styles cannot escape into the page.
//   * It is registered dynamically and only while you have it switched on. A
//     default install never injects this file anywhere.

(() => {
  const HOST_MARKER = "data-cogniflow-button";
  if (window.__cogniflowButton && document.querySelector(`[${HOST_MARKER}]`)) return;
  window.__cogniflowButton = true;

  // Keep the whole stack on screen however far the launcher is dragged.
  const EDGE_MARGIN = 12;
  // Travel that separates a drag from a click.
  const DRAG_THRESHOLD = 4;

  let context = null;
  let open = false;
  let creating = false;
  let busy = false;
  let note = null;
  let dragging = false;
  // True between pressing the launcher and letting go. A redraw in that
  // window swaps out the very element holding the pointer, which silently
  // kills the drag — so nothing is allowed to redraw while it is set.
  let pressing = false;
  let offset = 0.5;
  let host;
  let root;
  let body;
  let retired = false;

  // Reloading the extension orphans this script: the page goes on running it,
  // but every chrome.* call now throws "Extension context invalidated" — and
  // sendMessage throws it *synchronously*, so a trailing .catch() never sees
  // it and the error escapes into the page. Last time this left a dead button
  // behind; this time the copy notices and takes itself off the page.
  //
  // runtime.id is the canonical test: it is undefined once the context is gone.
  function extensionGone() {
    try { return !chrome?.runtime?.id; } catch { return true; }
  }

  function retire() {
    if (retired) return;
    retired = true;
    unmount();
  }

  async function send(message) {
    if (retired || extensionGone()) { retire(); return null; }
    try {
      return await chrome.runtime.sendMessage(message);
    } catch {
      if (extensionGone()) retire();
      return null;
    }
  }

  async function start() {
    const result = await send({ type: "PAGE_FOLDER_CONTEXT" });
    // Switched off, revoked, or a site on your private list: leave no trace.
    if (!result?.ok || !result.result?.enabled) return;
    context = result.result;
    offset = clampOffset(context.offset);
    mount();
  }

  function clampOffset(value) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(0.92, Math.max(0.08, number)) : 0.5;
  }

  function mount() {
    // Anything left behind by a previous instance of the extension goes first.
    document.querySelectorAll(`[${HOST_MARKER}]`).forEach(stale => stale.remove());
    host = document.createElement("div");
    host.setAttribute(HOST_MARKER, "");
    // The page owns its own layout; this sits above it and affects nothing.
    host.style.cssText = "all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;";
    root = host.attachShadow({ mode: "closed" });
    body = document.createElement("div");
    root.append(styles(), body);
    (document.body || document.documentElement).append(host);
    draw();
    document.addEventListener("keydown", onKeyDown, true);
    // Capture phase, so a page that swallows clicks on its own elements
    // cannot leave the stack stuck open behind whatever you pressed.
    document.addEventListener("pointerdown", onPointerDownOutside, true);
  }

  // composedPath() reaches through the shadow boundary, so a press on a row
  // inside the stack still counts as inside.
  function onPointerDownOutside(event) {
    if (!open || dragging) return;
    if (event.composedPath().includes(host)) return;
    setOpen(false);
  }

  function unmount() {
    document.removeEventListener("keydown", onKeyDown, true);
    document.removeEventListener("pointerdown", onPointerDownOutside, true);
    host?.remove();
    // So that switching the feature back on and re-injecting this file into
    // the same tab builds the button again instead of finding the flag set.
    window.__cogniflowButton = false;
  }

  // Turning the switch off takes the button off pages that are already open,
  // rather than leaving it there until each one is reloaded.
  try {
    chrome.runtime.onMessage.addListener((message, sender) => {
      if (retired || sender?.id !== chrome.runtime.id) return;
      if (message?.type === "COGNIFLOW_UNMOUNT") retire();
    });
  } catch { /* an orphaned copy; retire() below clears it up */ }

  // Folders change in the panel, in another tab's button, and on this page.
  // Without this the page keeps whatever list it read when it loaded, so a
  // folder made five minutes ago simply is not there to save into.
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (retired || area !== "local" || !host?.isConnected) return;
      if (changes.folders || changes.floatingButtonEnabled || changes.excludedDomains) void sync();
    });
  } catch { /* an orphaned copy; retire() below clears it up */ }

  async function sync() {
    // A redraw mid-gesture would replace the element holding the pointer.
    if (dragging || pressing) return;
    if (await refresh()) draw();
  }

  function onKeyDown(event) {
    if (event.key === "Escape" && open) setOpen(false);
  }

  // The stack opens and closes only when you say so. It used to open on
  // hover, which meant it appeared while you were reading the page behind it
  // and needed delays, a pinned flag and a close timer to stay out of its own
  // way. A click says what a hover only guesses at, and all of that goes.
  function setOpen(next) {
    if (next === open || pressing) return;
    open = next;
    if (!next) { creating = false; note = null; }
    draw();
    // Re-read on the way open: a tab that was discarded or backgrounded may
    // have missed the change events, and a stale list here is the one thing
    // that makes the button useless.
    if (next) void sync();
  }

  function styles() {
    const element = document.createElement("style");
    // CogniFlow's own tokens, restated here because a shadow root inherits
    // nothing from the extension's stylesheet.
    element.textContent = `
      :host { all: initial; }
      * { box-sizing: border-box; margin: 0; font-family: Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif; }

      .dock {
        position: fixed;
        right: 10px;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 6px;
        pointer-events: auto;
        transform: translateY(-100%);
      }
      .dock.is-dragging { user-select: none; }

      /* The stack grows upward out of the launcher, the way a menu docked to
         the bottom of its trigger has to. */
      .stack {
        display: flex;
        width: 236px;
        flex-direction: column;
        gap: 6px;
        margin-bottom: 2px;
      }

      .row {
        display: flex;
        width: 100%;
        min-height: 36px;
        align-items: center;
        gap: 9px;
        padding: 0 12px;
        border: 1px solid #e5e8ee;
        border-radius: 12px;
        background: #ffffff;
        color: #16181d;
        box-shadow: 0 2px 8px rgba(16, 24, 40, .07);
        font-size: 13px;
        font-weight: 500;
        text-align: left;
        cursor: pointer;
        transition: border-color .12s ease, background .12s ease, color .12s ease;
      }
      .row:hover { border-color: #cddffb; background: #eff4ff; }
      .row:focus-visible { outline: 2px solid #93b4fb; outline-offset: 2px; }
      .row svg { width: 15px; height: 15px; flex: 0 0 15px; fill: none; stroke: currentColor; stroke-width: 1.6; stroke-linecap: round; stroke-linejoin: round; }
      .label { overflow: hidden; flex: 1; text-overflow: ellipsis; white-space: nowrap; }
      .count { flex: 0 0 auto; color: #828b9b; font-size: 11px; font-weight: 500; }

      /* The title strip: the name opens the panel, the cross closes the
         stack. Two jobs that belong at the top, in one row. */
      .head {
        display: flex;
        min-height: 36px;
        align-items: center;
        justify-content: space-between;
        gap: 4px;
        padding: 0 7px 0 4px;
        border-radius: 12px;
        background: linear-gradient(97deg, #2563eb, #1d4ed8);
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(16, 24, 40, .07);
        font-size: 13px;
        font-weight: 650;
      }
      .head-open {
        display: flex;
        min-width: 0;
        flex: 1;
        align-items: center;
        justify-content: space-between;
        gap: 9px;
        padding: 7px 8px;
        border: 0;
        border-radius: 9px;
        background: transparent;
        color: inherit;
        font: inherit;
        text-align: left;
        cursor: pointer;
        transition: background .12s ease;
      }
      .head-open:hover { background: rgba(255, 255, 255, .16); }
      .head-open:focus-visible { outline: 2px solid #ffffff; outline-offset: -2px; }
      .head-icon { display: grid; flex: 0 0 auto; place-items: center; color: rgba(255, 255, 255, .85); }
      .head-icon svg { display: block; width: 15px; height: 15px; fill: none; stroke: currentColor; stroke-width: 1.6; stroke-linejoin: round; }
      .close {
        display: grid;
        width: 24px;
        height: 24px;
        flex: 0 0 24px;
        place-items: center;
        padding: 0;
        border: 0;
        border-radius: 7px;
        background: transparent;
        color: rgba(255, 255, 255, .78);
        cursor: pointer;
        transition: background .12s ease, color .12s ease;
      }
      .close:hover { color: #ffffff; background: rgba(255, 255, 255, .2); }
      .close:focus-visible { outline: 2px solid #ffffff; outline-offset: -2px; }
      .close svg { width: 12px; height: 12px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; }
      .row.folder { color: #16181d; }
      .row.folder .mark { display: grid; width: 22px; height: 22px; flex: 0 0 22px; place-items: center; border-radius: 8px; background: #eff4ff; color: #2563eb; }
      .row.folder .mark svg { width: 13px; height: 13px; }
      .row.is-saved .mark { background: #eaf6ee; color: #15803d; }
      .row.is-saved .count { color: #15803d; }
      .row.quiet { color: #596274; }

      /* Rows arrive one after another rather than all at once: at this size a
         block of five appearing in one frame reads as a pop-up. The animation
         moves them and nothing else — nothing here fades in from nothing, so
         a paused or disabled animation leaves the stack readable rather than
         invisible. */
      .dock.is-open .stack > * { animation: row-in .16s ease-out; }
      .dock.is-open .stack > :nth-child(1) { animation-delay: 0ms; }
      .dock.is-open .stack > :nth-child(2) { animation-delay: 20ms; }
      .dock.is-open .stack > :nth-child(3) { animation-delay: 40ms; }
      .dock.is-open .stack > :nth-child(4) { animation-delay: 60ms; }
      .dock.is-open .stack > :nth-child(5) { animation-delay: 80ms; }
      .dock.is-open .stack > :nth-child(n + 6) { animation-delay: 100ms; }
      @keyframes row-in { from { transform: translateX(10px); } to { transform: translateX(0); } }

      /* Twenty folders is a legal number of folders, and the stack grows
         upward: without a cap the top of it leaves the window. */
      .folders {
        display: flex;
        max-height: 40vh;
        flex-direction: column;
        gap: 6px;
        overflow-y: auto;
        /* Reaching the end of this list should not start scrolling the page
           underneath it. */
        overscroll-behavior: contain;
        /* Room for the rows' own shadows inside the scrolling box. */
        margin: -3px;
        padding: 3px;
      }
      .folders::-webkit-scrollbar { width: 6px; }
      .folders::-webkit-scrollbar-thumb { border-radius: 3px; background: rgba(16, 24, 40, .2); }
      .folders::-webkit-scrollbar-track { background: transparent; }

      .form { display: flex; gap: 6px; }
      .form input {
        min-width: 0;
        flex: 1;
        height: 36px;
        padding: 0 10px;
        border: 1px solid #d4d9e2;
        border-radius: 12px;
        background: #ffffff;
        color: #16181d;
        font: inherit;
        font-size: 13px;
      }
      .form input:focus { border-color: #2563eb; outline: 2px solid #93b4fb; outline-offset: 1px; }
      .form input, .form button { box-shadow: 0 2px 8px rgba(16, 24, 40, .07); }
      .form button {
        height: 36px;
        padding: 0 14px;
        border: 0;
        border-radius: 12px;
        background: #2563eb;
        color: #ffffff;
        font: inherit;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
      }
      .form button:disabled { opacity: .5; cursor: not-allowed; }

      .note { padding: 8px 12px; border-radius: 12px; background: #16181d; color: #ffffff; font-size: 12px; line-height: 1.45; }
      .note.is-error { background: #b42318; }

      /* The launcher is the product's mark, the way the reference is its own:
         a neutral glyph on a white chip is unrecognisable at this size on a
         page you did not expect it on. It is also its own drag handle. */
      .pin {
        position: relative;
        display: grid;
        width: 34px;
        height: 34px;
        place-items: center;
        padding: 0;
        border: 0;
        border-radius: 12px;
        background: transparent;
        cursor: pointer;
        opacity: .9;
        /* So a press-and-drag is a drag, not the page scrolling under it. */
        touch-action: none;
        transition: opacity .15s ease, transform .12s ease;
      }
      .dock.is-dragging .pin { cursor: grabbing; }
      .pin:hover, .pin:focus-visible, .dock.is-open .pin { opacity: 1; transform: scale(1.06); }
      .pin:focus-visible { outline: 2px solid #93b4fb; outline-offset: 3px; border-radius: 12px; }
      .pin .logo { width: 34px; height: 34px; border-radius: 10px; box-shadow: 0 2px 7px rgba(16, 24, 40, .14); }
      /* Already in a folder: a tick on the corner of the mark, so the state
         is readable without opening anything. */
      .badge {
        position: absolute;
        right: -3px;
        bottom: -3px;
        display: grid;
        width: 15px;
        height: 15px;
        place-items: center;
        border: 2px solid #ffffff;
        border-radius: 50%;
        background: #15803d;
        color: #ffffff;
      }
      .badge svg { width: 9px; height: 9px; fill: none; stroke: currentColor; stroke-width: 2.6; stroke-linecap: round; stroke-linejoin: round; }


      @media (prefers-reduced-motion: reduce) {
        .dock.is-open .stack > * { animation: none; }
      }
    `;
    return element;
  }

  const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);

  const ICON = {
    // The CogniFlow mark itself, inlined: a content script cannot load a file
    // from the extension without making it web-accessible to every page, and
    // the logo is the one thing on the launcher that has to be recognisable.
    // Ids are safe here — a shadow root scopes them.
    logo: `<svg class="logo" viewBox="0 0 59 59" fill="none" aria-hidden="true">
      <rect width="58.66" height="58.7" rx="17.46" fill="url(#cf-mark)"/>
      <path fill="#fff" fill-rule="evenodd" clip-rule="evenodd" d="M34.6637 21.3665C33.0847 20.3115 31.2283 19.7483 29.3292 19.7483V10.1465C33.1273 10.1465 36.8402 11.2728 39.9982 13.3829C43.1563 15.493 45.6176 18.4922 47.0711 22.0012C48.5246 25.5102 48.9049 29.3715 48.1639 33.0966C47.4229 36.8218 45.594 40.2436 42.9082 42.9292C40.2226 45.615 36.8008 47.4439 33.0757 48.1849C29.3505 48.9259 25.4892 48.5456 21.9802 47.0921C18.4712 45.6386 15.472 43.1772 13.3619 40.0192C11.2518 36.8612 10.1255 33.1483 10.1255 29.3502H19.7273C19.7273 31.2493 20.2905 33.1057 21.3455 34.6847C22.4006 36.2637 23.9002 37.4944 25.6548 38.2212C27.4092 38.9479 29.3399 39.138 31.2024 38.7675C33.065 38.3971 34.7759 37.4826 36.1188 36.1398C37.4616 34.7968 38.3761 33.086 38.7465 31.2234C39.117 29.3609 38.9269 27.4302 38.2002 25.6758C37.4734 23.9212 36.2427 22.4216 34.6637 21.3665Z"/>
      <path fill="#fff" fill-rule="evenodd" clip-rule="evenodd" d="M19.7273 10.1465C19.7273 11.4074 19.479 12.656 18.9964 13.821C18.5139 14.9859 17.8066 16.0444 16.915 16.936C16.0234 17.8276 14.9649 18.5349 13.8 19.0174C12.635 19.5 11.3864 19.7483 10.1255 19.7483L10.1255 29.3502C12.6474 29.3502 15.1445 28.8535 17.4744 27.8884C19.8043 26.9233 21.9214 25.5088 23.7045 23.7255C25.4878 21.9424 26.9023 19.8253 27.8674 17.4954C28.8325 15.1655 29.3292 12.6683 29.3292 10.1465L19.7273 10.1465Z"/>
      <defs><linearGradient id="cf-mark" x1="0" y1="0" x2="58.7" y2="58.66" gradientUnits="userSpaceOnUse"><stop stop-color="#2563EB"/><stop offset="1" stop-color="#1D4FD8"/></linearGradient></defs>
    </svg>`,
    folder: `<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2.75 6.25a1.5 1.5 0 0 1 1.5-1.5h3l1.75 2h5.75a1.5 1.5 0 0 1 1.5 1.5v6.5a1.5 1.5 0 0 1-1.5 1.5H4.25a1.5 1.5 0 0 1-1.5-1.5z"/></svg>`,
    plus: `<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 4.5v11M4.5 10h11"/></svg>`,
    clock: `<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="6.5"/><path d="M10 6.5V10l2.5 1.6"/></svg>`,
    close: `<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5.5 5.5 9 9M14.5 5.5l-9 9"/></svg>`,
    panel: `<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4" width="14" height="12" rx="2"/><path d="M12.5 4v12"/></svg>`,
    tick: `<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m4.5 10.5 3.5 3.5 7.5-8"/></svg>`,
  };

  function draw() {
    // A timer, a storage event or a stray listener can reach this after the
    // widget has been taken off the page. Drawing into a detached node is
    // pointless; throwing on the way is worse.
    if (retired || !body || !context) return;
    const saved = (context.savedIn || []).length > 0;
    const folders = context.folders || [];
    const savedIn = new Set(context.savedIn || []);

    const folderRows = folders.map(folder => `
      <button class="row folder ${savedIn.has(folder.id) ? "is-saved" : ""}" type="button" data-folder-id="${escapeHtml(folder.id)}">
        <span class="mark">${savedIn.has(folder.id) ? ICON.tick : ICON.folder}</span>
        <span class="label">${escapeHtml(folder.name)}</span>
        <span class="count">${folder.count}</span>
      </button>`).join("");

    const stack = open ? `
      <div class="stack">
        <div class="head">
          <button class="head-open" type="button" data-act="panel">CogniFlow<span class="head-icon" aria-hidden="true">${ICON.panel}</span></button>
          <button class="close" type="button" data-act="close" aria-label="Close">${ICON.close}</button>
        </div>
        ${folders.length ? `<div class="folders">${folderRows}</div>` : ""}
        ${creating || !folders.length
          ? `<form class="form"><input name="name" type="text" maxlength="40" placeholder="${folders.length ? "New folder" : "Name your first folder"}" aria-label="New folder name" autocomplete="off" /><button type="submit" ${busy ? "disabled" : ""}>Save</button></form>`
          : `<button class="row quiet" type="button" data-act="new">${ICON.plus}<span class="label">New folder</span></button>`}
        <button class="row quiet" type="button" data-act="remind">${ICON.clock}<span class="label">Remind me in ${context.reminderMinutes || 20} min</span></button>
        ${note ? `<p class="note ${note.error ? "is-error" : ""}" role="status">${escapeHtml(note.text)}</p>` : ""}
      </div>` : "";

    body.innerHTML = `
      <div class="dock ${open ? "is-open" : ""} ${dragging ? "is-dragging" : ""}" style="top: ${(offset * 100).toFixed(2)}%">
        ${stack}
        <button class="pin ${saved ? "is-saved" : ""}" type="button" aria-expanded="${open}"
          aria-label="${saved ? "This tab is in a CogniFlow folder" : "Save this tab to CogniFlow"}"
          title="${saved ? "In a folder" : "Save this tab to CogniFlow"} \u00b7 drag to move">${ICON.logo}${saved ? `<span class="badge" aria-hidden="true">${ICON.tick}</span>` : ""}</button>
      </div>`;

    bind();
    keepOnScreen();
  }

  // The stack grows upward out of the launcher, so a launcher near the top of
  // the window would push its own rows off the screen. Measure what is drawn
  // and slide the whole thing down by however much it overflowed. The stored
  // offset is left alone: where you put the launcher is a preference, and
  // only the menu needs the extra room.
  function keepOnScreen(dock = body.querySelector(".dock")) {
    // Only the open stack is tall enough to need this. Running it on the
    // collapsed launcher risks moving a button the user placed deliberately.
    if (!dock || !open) return;
    const rect = dock.getBoundingClientRect();
    if (rect.top >= EDGE_MARGIN) return;
    dock.style.top = `${Math.round(rect.height) + EDGE_MARGIN}px`;
  }

  function bind() {
    const dock = body.querySelector(".dock");

    bindLauncher(body.querySelector(".pin"), dock);
    body.querySelector('[data-act="close"]')?.addEventListener("click", () => setOpen(false));
    body.querySelector('[data-act="panel"]')?.addEventListener("click", openPanel);

    body.querySelectorAll("[data-folder-id]").forEach(button =>
      button.addEventListener("click", () => save({ folderId: button.dataset.folderId })));
    body.querySelector('[data-act="new"]')?.addEventListener("click", () => { creating = true; note = null; draw(); body.querySelector(".form input")?.focus(); });
    body.querySelector('[data-act="remind"]')?.addEventListener("click", remind);

    const form = body.querySelector("form");
    if (form) {
      form.addEventListener("submit", event => { event.preventDefault(); save({ folderName: form.elements.name.value }); });
      if (creating) form.elements.name.focus();
    }
  }

  // The launcher is its own handle: press and move it to reposition, press
  // and release to open. A separate grip was there before, and it was a 13px
  // target nobody could be expected to find — the thing you want to move is
  // the thing you can see, so that is the thing that moves.
  //
  // Vertical only. The widget is docked to the right edge, and letting it
  // wander into the middle of the page would put it over the content it is
  // there to help you keep.
  function bindLauncher(pin, dock) {
    let startY = 0;
    let startOffset = 0;
    let pressed = false;
    let moved = false;

    pin.addEventListener("pointerdown", event => {
      if (event.button !== 0) return;
      pressed = true;
      pressing = true;
      moved = false;
      startY = event.clientY;
      startOffset = offset;
      // Capture keeps the drag alive if the pointer leaves the 34px target,
      // but it is an optimisation: a browser that refuses it must not cost
      // us the press itself.
      try { pin.setPointerCapture(event.pointerId); } catch { /* drag still works without it */ }
    });

    pin.addEventListener("pointermove", event => {
      if (!pressed) return;
      const delta = event.clientY - startY;
      // A few pixels of travel between press and release is a click with an
      // unsteady hand, not a drag.
      if (!moved && Math.abs(delta) < DRAG_THRESHOLD) return;
      if (!moved) { moved = true; dragging = true; dock.classList.add("is-dragging"); }
      offset = clampOffset(startOffset + delta / Math.max(1, window.innerHeight));
      dock.style.top = `${(offset * 100).toFixed(2)}%`;
      // Dragging an open stack upward stops where its rows would leave the
      // window, rather than sliding them out of reach.
      keepOnScreen(dock);
    });

    const release = event => {
      if (!pressed) return;
      pressed = false;
      pressing = false;
      // This throws if the capture was never taken or was already released —
      // and throwing here would swallow the click it is standing in front of.
      try { pin.releasePointerCapture?.(event.pointerId); } catch { /* nothing to release */ }
      if (!moved) {
        // A press with no travel: toggle, as a button would.
        setOpen(!open);
        return;
      }
      dragging = false;
      dock.classList.remove("is-dragging");
      // An orphaned copy should go at the first interaction of any kind, not
      // sit there looking alive until someone clicks a folder and nothing
      // happens.
      if (extensionGone()) { retire(); return; }
      // Where you put it is a preference, so it is kept like one. Wrapped
      // because this one can throw synchronously, inside a pointerup handler,
      // where an exception would also cost the click.
      try {
        void chrome.storage.local.set({ floatingButtonOffset: offset }).catch(() => undefined);
      } catch { retire(); }
    };
    pin.addEventListener("pointerup", release);
    pin.addEventListener("pointercancel", release);
    // The click that follows a drag would otherwise open the stack you were
    // only trying to move out of the way.
    pin.addEventListener("click", event => {
      if (!moved) return;
      event.preventDefault();
      event.stopPropagation();
    });
  }


  async function refresh() {
    const result = await send({ type: "PAGE_FOLDER_CONTEXT" });
    // Switched off, or this site was just made private, while the stack was open.
    if (!result?.ok || !result.result?.enabled) { retire(); return false; }
    context = result.result;
    return true;
  }

  async function save(choice) {
    if (busy) return;
    busy = true;
    // No URL is sent: the worker reads it from the tab this message came from.
    const response = await send({ type: "PAGE_SAVE_TAB", ...choice });
    busy = false;
    if (!response?.ok) { note = { text: response?.error || "Could not save this tab.", error: true }; draw(); return; }
    if (!await refresh()) return;
    creating = false;
    // The stack stays open with a tick on the folder: you may want this page
    // in two of them, and closing would hide the only confirmation there is.
    const where = response.result?.folderName;
    note = { text: where ? `Saved to ${where}. It stays until you remove it.` : "Saved. It stays until you remove it." };
    draw();
  }

  async function remind() {
    const response = await send({ type: "PAGE_REMIND_TAB" });
    // The worker reports the minutes it actually used; fall back to the
    // setting rather than printing "undefined min" if it ever answers without.
    const minutes = response?.result?.minutes || context.reminderMinutes || 20;
    note = response?.ok
      ? { text: `I'll remind you about this tab in ${minutes} min.` }
      : { text: response?.error || "Could not set a reminder.", error: true };
    draw();
  }

  async function openPanel() {
    // Sent inside the click handler with nothing awaited first, so the user
    // activation Chrome requires for sidePanel.open() travels with it.
    const response = await send({ type: "PAGE_OPEN_PANEL" });
    if (response?.ok) { setOpen(false); return; }
    // Chrome's own words, not a guess at what went wrong.
    note = { text: response?.error || "Could not open the panel. Use the toolbar button.", error: true };
    draw();
  }

  void start();
})();
