// Constants and data rules shared by the service worker, the side panel and
// the preview. Loaded as a classic script (importScripts in the worker,
// <script> in the pages), so it publishes one global: CogniFlow.
(() => {
  const STORAGE_DEFAULTS = Object.freeze({
    onboardingComplete: false,
    trackingEnabled: false,
    idleRemindersEnabled: false,
    reminderMinutes: 10,
    showTabTitleInReturnAlert: true,
    pendingReturn: null,
    lastReminderWindowId: null,
    workflows: [],
    excludedDomains: [],
    // Forgotten-tab reminders. tabWatch is null until the worker first writes it.
    tabRemindersEnabled: false,
    tabReminderMinutes: 20,
    // Blink the toolbar icon (orange) while something needs you.
    blinkToolbarIcon: true,
    tabWatch: null
  });

  const MAX_WORKFLOWS = 30;
  // Tabs kept per workflow. Open tabs are never dropped; the oldest closed
  // ones are, since the point of keeping them is recent recovery.
  const MAX_WORKFLOW_TABS = 60;
  // CogniFlow keeps at most one day of history. Anything older is dropped by
  // the sanitize functions below, which every read and write already calls,
  // so no code path can resurrect expired work.
  const RETENTION_MS = 24 * 60 * 60 * 1000;
  const SESSION_GAP_MS = 20 * 60 * 1000;
  // A window's tabs turning over means you moved on to something else, even
  // without a pause. Below this share of the previous tabs surviving, the
  // next capture starts a new workflow instead of extending the old one.
  const WORKFLOW_TURNOVER_RATIO = 0.34;
  // Turnover is only meaningful once there were a few tabs to turn over.
  const MIN_TABS_FOR_TURNOVER = 3;
  const NOTE_MAX_LENGTH = 160;
  const REMINDER_MINUTES = Object.freeze([5, 10, 15]);

  const TAB_REMINDER_MINUTES = Object.freeze([10, 20, 30]);
  // Time spent on a tab before leaving it counts as "worked on it".
  const ENGAGED_MS = 30 * 1000;
  // One stretch on a tab counts for at most this long, so a tab left on
  // screen while you were away doesn't look like hours of work.
  const MAX_DWELL_SEGMENT_MS = 10 * 60 * 1000;
  // Title changes right after you leave are usually the page settling.
  const TITLE_CHANGE_GRACE_MS = 60 * 1000;
  const SNOOZE_MS = 10 * 60 * 1000;
  // Automatic nudges (not ones you set) are at least this far apart.
  const AUTO_NUDGE_GAP_MS = 15 * 60 * 1000;
  const MAX_WATCHED_TABS = 150;

  function normalizeDomain(value) {
    return String(value || "").trim().toLowerCase().replace(/^https?:\/\//, "").split(/[/:?#]/)[0];
  }

  // What the user types into "Private sites": strips scheme, path and "www.".
  function parseDomainInput(value) {
    let domain = normalizeDomain(value);
    if (domain.startsWith("www.")) domain = domain.slice(4);
    return /^(?=.{1,253}$)([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(domain) ? domain : "";
  }

  function isExcludedHost(hostname, domains) {
    const host = normalizeDomain(hostname);
    return domains.some(domain => host === domain || host.endsWith(`.${domain}`));
  }

  function safeWebUrl(url) {
    try {
      const parsed = new URL(url);
      return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.href : "";
    } catch {
      return "";
    }
  }

  function hostOf(url) {
    try { return normalizeDomain(new URL(url).hostname); } catch { return ""; }
  }

  // When a workflow was last worked in. Older saves may lack one of these.
  function workflowLastTouched(workflow) {
    if (Number.isFinite(workflow?.lastActive)) return workflow.lastActive;
    if (Number.isFinite(workflow?.createdAt)) return workflow.createdAt;
    return null;
  }

  // Storage is user-owned and may hold data from older versions; drop
  // anything that isn't a well-formed workflow, or is past the 24-hour
  // retention window, before code relies on it.
  function sanitizeWorkflows(value, now = Date.now()) {
    if (!Array.isArray(value)) return [];
    const cutoff = now - RETENTION_MS;
    return value
      .filter(workflow => workflow && typeof workflow.id === "string" && Array.isArray(workflow.tabs))
      // A workflow with no usable timestamp can't be shown to have happened
      // inside the window, so it goes too.
      .filter(workflow => workflowLastTouched(workflow) >= cutoff)
      .map(workflow => ({
        ...workflow,
        tabs: workflow.tabs
          .filter(tab => tab && typeof tab === "object" && typeof tab.url === "string")
          // Notes, "done" marks and per-tab times from the retired "Pick up later" list are dropped.
          .map(({ note: _note, pickupDoneAt: _done, lastActive: _lastActive, ...tab }) => tab)
      }));
  }

  // A capture sees only the tabs open right now. Merging it into what the
  // workflow already held is what lets CogniFlow remember a tab after you
  // close it — the one thing the browser's own tab strip cannot show you.
  //
  //   openedAt  when this workflow first saw the URL
  //   closedAt  when it stopped being open (null while it is open)
  //
  // A URL that comes back (reopened, or navigated back to) is live again.
  function mergeWorkflowTabs(previousTabs, currentTabs, now = Date.now()) {
    const previous = new Map();
    for (const tab of Array.isArray(previousTabs) ? previousTabs : []) {
      if (tab && typeof tab.url === "string") previous.set(tab.url, tab);
    }

    const open = currentTabs.map(tab => {
      const before = previous.get(tab.url);
      previous.delete(tab.url);
      return {
        ...before, ...tab,
        openedAt: before?.openedAt ?? before?.lastSeen ?? now,
        // Time in a tab only ever grows; a reopened tab starts a fresh count
        // under a new tab id, so keep whichever total is larger.
        activeMs: Math.max(before?.activeMs || 0, tab.activeMs || 0),
        // Chrome drops openerTabId once the opener closes, so a link already
        // recorded is kept rather than overwritten with nothing.
        openedFrom: tab.openedFrom ?? before?.openedFrom ?? null,
        closedAt: null
      };
    });

    // Whatever is left in `previous` is no longer open.
    const closed = [];
    for (const tab of previous.values()) {
      // A URL that was only passed through — a search result opened and left
      // in seconds — is noise, not something worth recovering. Measured as how
      // long it was part of the workspace, since `lastSeen` only advances when
      // a capture happens to run and a tab you simply read triggers none.
      // Time actually spent in it counts too, whichever is the stronger claim.
      const presentMs = now - (tab.openedAt ?? now);
      if (!Number.isFinite(tab.closedAt) && presentMs < ENGAGED_MS && (tab.activeMs || 0) < ENGAGED_MS) continue;
      closed.push({ ...tab, active: false, closedAt: Number.isFinite(tab.closedAt) ? tab.closedAt : now });
    }
    closed.sort((a, b) => b.closedAt - a.closedAt);

    // Open tabs are the workspace and always survive the cap.
    return [...open, ...closed.slice(0, Math.max(0, MAX_WORKFLOW_TABS - open.length))];
  }

  const isOpenTab = tab => !Number.isFinite(tab?.closedAt);

  // Does this capture belong to the workflow already in progress, or is it a
  // different piece of work? The old rule was the clock alone, which split a
  // task across a coffee break and merged two unrelated tasks done back to
  // back. Tab turnover answers the second case: swapping out most of what was
  // open is what moving on actually looks like.
  function workflowContinues(workflow, openUrls, now) {
    if (!workflow || !Number.isFinite(workflow.lastActive)) return false;
    if (now - workflow.lastActive >= SESSION_GAP_MS) return false;
    const previousOpen = (workflow.tabs || []).filter(isOpenTab);
    if (previousOpen.length < MIN_TABS_FOR_TURNOVER) return true;
    const current = new Set(openUrls);
    const kept = previousOpen.filter(tab => current.has(tab.url)).length;
    return kept / previousOpen.length >= WORKFLOW_TURNOVER_RATIO;
  }

  // Follow a tab's `openedFrom` links up to the tab it ultimately came from.
  // Chains can be broken (the opener was excluded, or belongs to another
  // workflow) and, through reopened URLs, can even loop, so this walks with a
  // depth cap and a seen-set and returns the furthest tab it can actually reach.
  function threadRoot(tab, byUrl) {
    let current = tab;
    const seen = new Set([tab.url]);
    for (let depth = 0; depth < 12; depth += 1) {
      const parent = current.openedFrom ? byUrl.get(current.openedFrom) : null;
      if (!parent || seen.has(parent.url)) break;
      seen.add(parent.url);
      current = parent;
    }
    return current;
  }

  // Group a workflow's tabs into the threads you actually opened: a tab you
  // followed a link into belongs with the tab you followed it from. Tabs you
  // opened directly, and never branched from, have no thread and are returned
  // separately rather than invented into one.
  function relatedThreads(tabs) {
    const list = (Array.isArray(tabs) ? tabs : []).filter(tab => tab && typeof tab.url === "string");
    const byUrl = new Map(list.map(tab => [tab.url, tab]));
    const groups = new Map();
    for (const tab of list) {
      const root = threadRoot(tab, byUrl);
      if (!groups.has(root.url)) groups.set(root.url, { root, tabs: [] });
      groups.get(root.url).tabs.push(tab);
    }

    const threads = [];
    const loose = [];
    for (const group of groups.values()) {
      // One tab on its own is not a thread, however it got opened.
      if (group.tabs.length < 2) loose.push(...group.tabs);
      else threads.push(group);
    }
    // Most-worked-in thread first; within a thread, the root leads.
    const spent = group => group.tabs.reduce((total, tab) => total + (tab.activeMs || 0), 0);
    for (const group of threads) {
      group.activeMs = spent(group);
      group.tabs.sort((a, b) => (a.url === group.root.url ? -1 : b.url === group.root.url ? 1 : (b.activeMs || 0) - (a.activeMs || 0)));
    }
    threads.sort((a, b) => b.activeMs - a.activeMs);
    loose.sort((a, b) => (b.activeMs || 0) - (a.activeMs || 0));
    return { threads, loose };
  }

  // The tab a workflow is really about: where you spent the most time, not
  // whichever one happened to be in front when the capture ran. Falling back
  // to the last active tab keeps a name on brand-new workflows, where nothing
  // has accumulated time yet.
  function workflowAnchor(tabs, activeUrl) {
    const open = (Array.isArray(tabs) ? tabs : []).filter(isOpenTab);
    if (!open.length) return null;
    const worked = open.filter(tab => (tab.activeMs || 0) > 0);
    if (!worked.length) return open.find(tab => tab.url === activeUrl) || open[0];
    return worked.reduce((best, tab) => {
      if ((tab.activeMs || 0) !== (best.activeMs || 0)) return (tab.activeMs || 0) > (best.activeMs || 0) ? tab : best;
      return (tab.lastSeen || 0) > (best.lastSeen || 0) ? tab : best;
    });
  }

  function removeDomainFromWorkflows(workflows, domain) {
    return workflows.map(workflow => {
      const tabs = workflow.tabs.filter(tab => !isExcludedHost(tab.hostname, [domain]));
      // tabCount is what was open, so the card doesn't count recovered tabs twice.
      const tabCount = tabs.filter(isOpenTab).length;
      const activeStillIncluded = tabs.some(tab => tab.url === workflow.activeUrl);
      if (activeStillIncluded) return { ...workflow, tabs, tabCount };
      // Prefer a tab that is still open when the named one is excluded away.
      const fallback = tabs.find(isOpenTab) || tabs[0];
      return { ...workflow, tabs, tabCount, title: fallback?.title || workflow.title, activeUrl: fallback?.url || "", activeTitle: fallback?.title || "" };
    }).filter(workflow => workflow.tabs.length);
  }

  // Every change the side panel makes to saved workflows is one of these
  // operations. The service worker applies them in the same queue as tab
  // captures, so the two never overwrite each other's writes.
  function applyWorkflowOp(workflows, op) {
    switch (op?.kind) {
      case "delete-workflow":
        return workflows.filter(workflow => workflow.id !== op.workflowId);
      case "exclude-domain":
        return removeDomainFromWorkflows(workflows, op.domain);
      case "include-domain":
        // Only the excluded-domain list changes; tabs removed earlier stay removed.
        return workflows;
      case "clear-all":
        return [];
      default:
        throw new Error(`Unknown workflow operation: ${op?.kind}`);
    }
  }

  // The excluded-domain list changes through the same operations, so adding
  // and removing a private site can't overwrite each other either.
  function applyExcludedDomainsOp(domains, op) {
    const list = Array.isArray(domains) ? domains : [];
    if (op?.kind === "exclude-domain") return list.includes(op.domain) ? list : [...list, op.domain].sort();
    if (op?.kind === "include-domain") return list.filter(domain => domain !== op.domain);
    return list;
  }

  // ---- Forgotten-tab reminders ------------------------------------------
  // tabWatch = { current: { tabId, since } | null, lastNudgeAt, tabs: { [tabId]: record } }
  // A record describes one open browser tab:
  //   engagedMs      time you spent on it (summed over visits)
  //   leftAt         when you last switched away (null while you're on it)
  //   titleChangedAt its title changed after you left (an AI answer finished, a new message...)
  //   waitingUntil   a reminder you asked for (or a snooze) is due at this time
  //   needsAttention CogniFlow already flagged it; shown in the panel and the badge
  //   reason         "waiting" | "changed" | "forgotten"
  //   doneAt         you said you're finished; no automatic reminders until you return
  //   note           optional text you added ("check Gemini's answer")

  function emptyTabWatch() {
    return { current: null, lastNudgeAt: 0, tabs: {} };
  }

  // The last time a watched tab was looked at, left, or nudged about.
  function tabRecordLastTouched(record) {
    return Math.max(record?.leftAt || 0, record?.firstSeen || 0, record?.nudgedAt || 0);
  }

  function sanitizeTabWatch(value, now = Date.now()) {
    if (!value || typeof value !== "object" || !value.tabs || typeof value.tabs !== "object") return emptyTabWatch();
    const current = value.current && Number.isInteger(value.current.tabId) && Number.isFinite(value.current.since) ? { ...value.current } : null;
    const cutoff = now - RETENTION_MS;
    const tabs = {};
    for (const [id, record] of Object.entries(value.tabs)) {
      if (!record || !Number.isInteger(record.tabId) || String(record.tabId) !== id || typeof record.url !== "string") continue;
      // The tab being looked at right now never goes stale, however long it
      // has been open.
      if (current?.tabId !== record.tabId && tabRecordLastTouched(record) < cutoff) continue;
      tabs[id] = { ...record };
    }
    return { current, lastNudgeAt: Number.isFinite(value.lastNudgeAt) ? value.lastNudgeAt : 0, tabs };
  }

  function newTabRecord(info, now) {
    return {
      tabId: info.tabId, windowId: info.windowId, url: info.url, title: info.title, hostname: info.hostname,
      firstSeen: now, engagedMs: 0, leftAt: null, titleChangedAt: null,
      waitingUntil: null, needsAttention: false, reason: null, nudgedAt: null, doneAt: null
    };
  }

  // Changes made from the panel, a notification button or the shortcut.
  function applyTabReminderOp(watch, op, now) {
    const next = sanitizeTabWatch(watch);
    const record = next.tabs[op?.tabId ?? op?.tab?.tabId];
    switch (op?.kind) {
      case "remind": {
        const minutes = TAB_REMINDER_MINUTES.includes(Number(op.minutes)) ? Number(op.minutes) : 20;
        const base = record || newTabRecord(op.tab, now);
        next.tabs[op.tab.tabId] = {
          ...base, url: op.tab.url, title: op.tab.title, hostname: op.tab.hostname, windowId: op.tab.windowId,
          waitingUntil: now + minutes * 60 * 1000, needsAttention: false, reason: "waiting", doneAt: null
        };
        return next;
      }
      case "snooze":
        if (record) Object.assign(record, { waitingUntil: now + SNOOZE_MS, needsAttention: false, doneAt: null });
        return next;
      case "done":
        if (record) Object.assign(record, { doneAt: now, waitingUntil: null, needsAttention: false });
        return next;
      case "set-note": {
        if (!record) return next;
        const note = String(op.note || "").trim().slice(0, NOTE_MAX_LENGTH);
        if (note) record.note = note;
        else delete record.note;
        return next;
      }
      case "drop-host":
        for (const [id, item] of Object.entries(next.tabs)) {
          if (isExcludedHost(item.hostname, [op.domain])) delete next.tabs[id];
        }
        if (next.current && !next.tabs[next.current.tabId]) next.current = null;
        return next;
      case "clear":
        return emptyTabWatch();
      default:
        throw new Error(`Unknown tab reminder operation: ${op?.kind}`);
    }
  }

  // Which tabs should be flagged now, most important first. The caller
  // applies rate limits and checks the tabs are still open.
  function dueTabReminders(watch, now, { autoEnabled, forgottenMs }) {
    const due = [];
    for (const record of Object.values(watch.tabs)) {
      if (watch.current?.tabId === record.tabId || record.needsAttention) continue;
      if (Number.isFinite(record.waitingUntil)) {
        if (record.waitingUntil <= now) due.push({ record, reason: "waiting", order: record.waitingUntil });
        continue;
      }
      if (!autoEnabled || record.doneAt || !Number.isFinite(record.leftAt) || record.engagedMs < ENGAGED_MS) continue;
      const awayMs = now - record.leftAt;
      const changedSinceNudge = Number.isFinite(record.titleChangedAt) && record.titleChangedAt > (record.nudgedAt || 0);
      if (changedSinceNudge && awayMs >= TITLE_CHANGE_GRACE_MS) due.push({ record, reason: "changed", order: record.titleChangedAt });
      else if (!record.nudgedAt && awayMs >= forgottenMs) due.push({ record, reason: "forgotten", order: record.leftAt });
    }
    const rank = { waiting: 0, changed: 1, forgotten: 2 };
    return due.sort((a, b) => rank[a.reason] - rank[b.reason] || a.order - b.order);
  }

  // Tabs to list in the panel: flagged ones first, then reminders still to come.
  function tabsNeedingAttention(watch) {
    const records = Object.values(watch.tabs);
    const flagged = records.filter(record => record.needsAttention).sort((a, b) => (b.nudgedAt || 0) - (a.nudgedAt || 0));
    const upcoming = records.filter(record => !record.needsAttention && Number.isFinite(record.waitingUntil)).sort((a, b) => a.waitingUntil - b.waitingUntil);
    return [...flagged, ...upcoming];
  }

  globalThis.CogniFlow = Object.freeze({
    STORAGE_DEFAULTS,
    MAX_WORKFLOWS,
    MAX_WORKFLOW_TABS,
    RETENTION_MS,
    mergeWorkflowTabs,
    isOpenTab,
    workflowContinues,
    workflowAnchor,
    relatedThreads,
    hostOf,
    WORKFLOW_TURNOVER_RATIO,
    SESSION_GAP_MS,
    NOTE_MAX_LENGTH,
    REMINDER_MINUTES,
    TAB_REMINDER_MINUTES,
    ENGAGED_MS,
    MAX_DWELL_SEGMENT_MS,
    TITLE_CHANGE_GRACE_MS,
    AUTO_NUDGE_GAP_MS,
    MAX_WATCHED_TABS,
    emptyTabWatch,
    sanitizeTabWatch,
    newTabRecord,
    applyTabReminderOp,
    dueTabReminders,
    tabsNeedingAttention,
    normalizeDomain,
    parseDomainInput,
    isExcludedHost,
    safeWebUrl,
    sanitizeWorkflows,
    workflowLastTouched,
    applyWorkflowOp,
    applyExcludedDomainsOp
  });
})();
