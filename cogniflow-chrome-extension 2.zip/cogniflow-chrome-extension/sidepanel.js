const app = document.getElementById("app");
const { STORAGE_DEFAULTS: DEFAULTS, safeWebUrl, REMINDER_MINUTES } = CogniFlow;
let state = { ...DEFAULTS };
let activeView = "recent";
let selectedWorkflowId = null;
let searchTerm = "";
let toastTimer;
let stateLoadRevision = 0;
let editingNoteTabId = null;
// Whether "Waiting on you" is opened. Remembered per browser; collapsed by default.
let attentionExpanded = readPreference("cogniflow.attentionExpanded") === "true";

function readPreference(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}

function writePreference(key, value) {
  try { localStorage.setItem(key, value); } catch { /* Storage blocked; the choice lasts until the panel closes. */ }
}

const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const timeLabel = time => {
  const timestamp = Number.isFinite(time) ? time : Date.now();
  const elapsed = Math.max(0, Date.now() - timestamp);
  if (elapsed < 60_000) return "just now";
  if (elapsed < 3_600_000) return `${Math.floor(elapsed / 60_000)}m ago`;
  if (elapsed < 86_400_000) return `${Math.floor(elapsed / 3_600_000)}h ago`;
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(timestamp);
};

async function loadState() {
  const revision = ++stateLoadRevision;
  const persisted = await chrome.storage.local.get(DEFAULTS);
  if (revision !== stateLoadRevision) return;
  state = { ...DEFAULTS, ...persisted };
  state.workflows = CogniFlow.sanitizeWorkflows(state.workflows);
  if (!Array.isArray(state.excludedDomains)) state.excludedDomains = [];
  state.tabWatch = CogniFlow.sanitizeTabWatch(state.tabWatch);
  render();
}

// Background tab activity re-renders the panel often, so keep whatever the
// user is typing (and their cursor) instead of wiping it on every redraw.
function captureDrafts() {
  const domainInput = document.getElementById("domain-input");
  const noteInput = document.getElementById("tab-note-input");
  const focused = document.activeElement;
  return {
    domain: domainInput?.value,
    note: noteInput ? { key: noteInput.dataset.noteKey, value: noteInput.value } : null,
    focus: focused?.id && app.contains(focused) ? { id: focused.id, start: focused.selectionStart, end: focused.selectionEnd } : null
  };
}

function restoreDrafts(drafts) {
  const domainInput = document.getElementById("domain-input");
  if (domainInput && drafts.domain) domainInput.value = drafts.domain;
  const noteInput = document.getElementById("tab-note-input");
  if (noteInput && drafts.note && noteInput.dataset.noteKey === drafts.note.key) noteInput.value = drafts.note.value;
  const focusTarget = drafts.focus && document.getElementById(drafts.focus.id);
  if (focusTarget) {
    focusTarget.focus();
    try { if (Number.isInteger(drafts.focus.start)) focusTarget.setSelectionRange(drafts.focus.start, drafts.focus.end); } catch { /* Not a text field. */ }
  }
}

function render() {
  const currentWorkflow = state.workflows.find(item => item.id === selectedWorkflowId);
  const drafts = captureDrafts();
  app.innerHTML = `
    <header class="topbar">
      <div class="brand-lockup"><img class="brand-mark" src="cogniflow-icon.svg" alt="" /><div><p class="brand-name">CogniFlow</p><p class="brand-tagline">Return to your flow</p></div></div>
      <div class="status-pill ${state.trackingEnabled ? "is-on" : ""}" aria-live="polite"><span class="status-dot"></span>${state.trackingEnabled ? "Remembering" : "Paused"}</div>
    </header>
    ${state.onboardingComplete ? `
      <nav class="tabs" role="tablist" aria-label="CogniFlow sections">
        ${tabButton("recent", "Recent Work")}${tabButton("related", "Related")}${tabButton("settings", "Settings")}
      </nav>
      ${returnBanner()}
      <main class="content">${activeView === "settings" ? settingsView() : activeView === "related" ? relatedView(currentWorkflow) : recentView(currentWorkflow)}</main>
    ` : onboardingView()}
  `;
  bindEvents();
  restoreDrafts(drafts);
}

function tabButton(view, label) {
  return `<button class="tab" role="tab" aria-selected="${activeView === view}" data-view="${view}">${label}</button>`;
}

function onboardingView() {
  return `<main class="content">
    <section class="card welcome">
      <div class="welcome-illustration" aria-hidden="true">${lockIcon()}</div>
      <h1>Start with trust.</h1>
      <p>CogniFlow keeps a small, local memory of your browser work so you can return after a distraction.</p>
      <div class="privacy-note">${lockIcon()}<span>With your permission, it saves tab titles and URLs on this device for 24 hours, then deletes them. You can add optional notes to remind yourself what to do next. It does not read page contents, messages, or keystrokes. Nothing is sent to a server.</span></div>
      <label class="consent"><input id="consent" type="checkbox" /><span>I understand what CogniFlow will save and can pause or delete it in Settings.</span></label>
      <button class="button onboarding-start" id="start" disabled>Enable local memory</button>
      <p class="small-help">Chrome will ask for access to your tabs. You can decline or turn it off later.</p>
    </section>
    <p class="small-help onboarding-footnote">Prototype · metadata only · stored using Chrome local extension storage</p>
  </main>`;
}

function recentView(current) {
  const matches = filteredWorkflows();
  return `<h1 class="page-title">Recent Work</h1><p class="page-subtitle">What you were doing — and where to pick up.</p>
    ${state.trackingEnabled ? "" : `<div class="alert">Memory is paused. Turn it on in Settings to save tab context as you work.</div>`}
    ${waitingOnView()}
    ${state.workflows.length ? `<input class="search" id="search" type="search" value="${escapeHtml(searchTerm)}" placeholder="Find a workflow" aria-label="Find a workflow" />${matches.length ? `<div class="workflow-list">${matches.map(item => workflowCard(item,current?.id)).join("")}</div>` : `<p class="small-help" role="status">No workflows match “${escapeHtml(searchTerm.trim())}”.</p>`}` : emptyState()}
    ${current ? `<div class="actions"><button class="button" data-action="continue" data-id="${escapeHtml(current.id)}">Continue Work <span aria-hidden="true">→</span></button></div>` : ""}
    ${state.trackingEnabled ? `<button class="button secondary capture-action" data-action="capture">Save this window now</button>` : ""}`;
}

function relatedView(current) {
  if (!current) return `<h1 class="page-title">Related</h1><p class="page-subtitle">Tabs saved together in a workflow.</p>${emptyState("No workflow selected", "Choose a workflow in Recent Work to see its related browser tabs.")}`;
  const allTabs = current.tabs || [];
  const openTabs = allTabs.filter(CogniFlow.isOpenTab);
  const closedTabs = allTabs.filter(tab => !CogniFlow.isOpenTab(tab));
  return `<div class="detail-head"><button class="back" aria-label="Back to recent work" data-action="back">←</button><h1 class="page-title">${escapeHtml(current.title)}</h1></div>
    <div class="summary"><p class="summary-label">Activity summary</p><p>${escapeHtml(summaryText(current))}</p></div>
    <div class="workflow-meta detail-meta"><span>${openTabs.length} still open</span><span>Updated ${timeLabel(current.lastActive)}</span></div>
    ${threadSections(openTabs, current.activeUrl)}
    ${closedTabs.length ? `<p class="section-kicker">You closed these</p>
    <div class="card saved-tabs-card is-closed-card"><div class="tab-list">${closedTabs.map(tab => savedTab(tab,current.activeUrl,true)).join("")}</div></div>
    <p class="small-help">Your browser forgets a tab the moment you close it. CogniFlow keeps it here for 24 hours so you can get it back.</p>` : ""}
    <p class="small-help">Tabs are grouped by which tab you opened them from — browser metadata only. CogniFlow does not read page content.</p>
    <div class="actions"><button class="button" data-action="continue" data-id="${escapeHtml(current.id)}">Continue Work <span aria-hidden="true">→</span></button><button class="button ghost" data-action="delete-workflow" data-id="${escapeHtml(current.id)}">Remove this workflow</button></div>`;
}

function settingsView() {
  const domains = state.excludedDomains || [];
  return `<h1 class="page-title">Settings</h1><p class="page-subtitle">Your data and capture boundaries.</p>
    <section class="card settings-card"><div class="setting-row"><div><h2>${state.trackingEnabled ? "Pause memory" : "Resume memory"}</h2><p>${state.trackingEnabled ? "CogniFlow is saving tab titles and URLs locally." : "Memory is paused. No new browser activity is saved."}</p></div><button class="switch" role="switch" aria-checked="${state.trackingEnabled}" aria-label="${state.trackingEnabled ? "Pause memory" : "Resume memory"}" data-action="toggle-memory"></button></div></section>
    <p class="section-kicker">Reminders</p>
    <section class="card settings-card"><div class="setting-row"><div><h2>When you come back</h2><p>You stepped away and returned. CogniFlow shows the tab you were last working in.</p></div><button class="switch" role="switch" aria-checked="${state.idleRemindersEnabled}" aria-label="${state.idleRemindersEnabled ? "Turn off come-back reminders" : "Turn on come-back reminders"}" data-action="toggle-reminders"></button></div><label class="small-help settings-label" for="reminder-minutes">Count me away after</label><select class="search select-control" id="reminder-minutes">${REMINDER_MINUTES.map(minutes => `<option value="${minutes}" ${Number(state.reminderMinutes) === minutes ? "selected" : ""}>${minutes} minutes</option>`).join("")}</select><p class="small-help">Counts time away from your whole computer, not just Chrome.</p><button class="button secondary test-reminder" data-action="test-reminder" ${state.idleRemindersEnabled ? "" : "disabled"}>Send a test reminder</button></section>
    <section class="card settings-card"><div class="setting-row"><div><h2>While you're working</h2><p>You never stopped, but a tab did. CogniFlow nudges you about one you left open mid-task — like an AI answer that finished after you moved on.</p></div><button class="switch" role="switch" aria-checked="${state.tabRemindersEnabled}" aria-label="${state.tabRemindersEnabled ? "Turn off forgotten-tab nudges" : "Turn on forgotten-tab nudges"}" data-action="toggle-tab-reminders"></button></div><label class="small-help settings-label" for="tab-reminder-minutes">Nudge me after a tab sits for</label><select class="search select-control" id="tab-reminder-minutes">${CogniFlow.TAB_REMINDER_MINUTES.map(minutes => `<option value="${minutes}" ${Number(state.tabReminderMinutes) === minutes ? "selected" : ""}>${minutes} minutes</option>`).join("")}</select><p class="small-help">Also the delay for “Remind me about this tab” (<kbd>${SHORTCUT_LABEL}</kbd>), which works even with this off.</p></section>
    <section class="card settings-card"><h2>How you're alerted</h2><div class="preference-list">
      <label class="consent"><input id="blink-toolbar-icon" type="checkbox" ${state.blinkToolbarIcon ? "checked" : ""}/><span>Blink the toolbar icon when something needs you.</span></label>
      <label class="consent"><input id="show-tab-title" type="checkbox" ${state.showTabTitleInReturnAlert ? "checked" : ""}/><span>Show tab titles and notes in notifications. Anyone near your screen could see them.</span></label>
    </div></section>
    <section class="card settings-card"><h2>Private sites</h2><p>Tabs on these domains are excluded from saved workflows, including their subdomains.</p><form class="domain-form" id="domain-form"><input class="domain-input" id="domain-input" placeholder="example.com" aria-label="Website domain" autocomplete="off"/><button class="button domain-add" type="submit">Add</button></form><div class="domain-list">${domains.length ? domains.map(domain => `<div class="domain-item"><span>${escapeHtml(domain)}</span><button class="domain-remove" data-action="remove-domain" data-domain="${escapeHtml(domain)}" aria-label="Remove ${escapeHtml(domain)}">×</button></div>`).join("") : `<span class="small-help">No excluded sites yet.</span>`}</div></section>
    <section class="card settings-card"><h2>What CogniFlow stores</h2><div class="privacy-list"><span>Only the last 24 hours — older work deletes itself</span><span>Tab titles, URLs, and activity timestamps on this device</span><span>Tabs you closed, so you can get them back</span><span>Optional notes you add to a tab reminder</span><span>No page text, screenshots, messages, or keystrokes</span><span>No server upload or account sync</span></div></section>
    <section class="card settings-card"><h2>Delete saved activity</h2><p>CogniFlow already deletes anything older than 24 hours. This clears everything now.</p><button class="button danger settings-delete-button" data-action="clear-data">Delete all saved work</button></section>
    <p class="small-help">CogniFlow is a prototype. Memory runs only after the tab-access permission and consent are enabled.</p>`;
}

const SHORTCUT_LABEL = /Mac/i.test(navigator.platform) ? "⌥⇧W" : "Alt+Shift+W";

function tabReminderMinutes() {
  return CogniFlow.TAB_REMINDER_MINUTES.includes(Number(state.tabReminderMinutes)) ? Number(state.tabReminderMinutes) : DEFAULTS.tabReminderMinutes;
}

function attentionReason(record) {
  if (!record.needsAttention) {
    const minutes = Math.max(1, Math.ceil((record.waitingUntil - Date.now()) / 60_000));
    return `Reminder in ${minutes} min`;
  }
  if (record.reason === "changed") return "Changed after you left — may be ready";
  if (record.reason === "forgotten") {
    const worked = Math.max(1, Math.round((record.engagedMs || 0) / 60_000));
    return `You spent ${worked} min here · left ${timeLabel(record.leftAt)}`;
  }
  return "Reminder you set";
}

// Tabs CogniFlow is reminding you about (or will), with the reason for each.
function waitingOnView() {
  if (!state.trackingEnabled) return "";
  const records = CogniFlow.tabsNeedingAttention(state.tabWatch);
  const flagged = records.filter(record => record.needsAttention).length;
  const summary = records.length
    ? `${records.length} open tab${records.length === 1 ? "" : "s"} you left mid-task${flagged ? ` · ${flagged} need${flagged === 1 ? "s" : ""} you now` : ""}`
    : "Nothing waiting. Leaving a task running? Set a reminder for a tab.";
  return `<section class="attention-section ${attentionExpanded ? "is-expanded" : ""}" aria-labelledby="attention-heading">
    <h2 class="attention-title" id="attention-heading"><button class="attention-toggle" type="button" data-action="toggle-attention" aria-expanded="${attentionExpanded}" aria-controls="attention-body">
      <span class="attention-heading-copy"><span class="attention-heading-text">Waiting on you</span><span class="attention-summary">${escapeHtml(summary)}</span></span>
      ${flagged ? `<span class="pickup-count" aria-label="${flagged} need attention">${flagged}</span>` : ""}
      <svg class="attention-chevron" viewBox="0 0 20 20" aria-hidden="true"><path d="M5.5 7.5 10 12l4.5-4.5"/></svg>
    </button></h2>
    <div id="attention-body" class="attention-body" ${attentionExpanded ? "" : "hidden"}>
      ${records.length ? `<div class="pickup-list">${records.map(attentionItem).join("")}</div>` : ""}
      <button class="remind-current" type="button" data-action="remind-current">+ Remind me about this tab in ${tabReminderMinutes()} min <span class="shortcut-hint">${SHORTCUT_LABEL}</span></button>
    </div>
  </section>`;
}

function attentionItem(record) {
  const title = record.title || record.hostname;
  const editing = editingNoteTabId === record.tabId;
  return `<article class="pickup-item ${record.needsAttention ? "is-flagged" : ""}">
    <button class="pickup-return" type="button" data-action="tab-go" data-tab-id="${record.tabId}" aria-label="Go back to ${escapeHtml(title)}">
      <span class="pickup-copy"><span class="pickup-title">${escapeHtml(title)}</span><span class="pickup-meta">${escapeHtml(record.hostname)} · <span class="pickup-reason">${escapeHtml(attentionReason(record))}</span></span></span>
      <span class="pickup-action" aria-hidden="true">↗</span>
    </button>
    ${record.note && !editing ? `<p class="pickup-saved-note">${escapeHtml(record.note)}</p>` : ""}
    ${editing ? tabNoteEditor(record) : attentionItemFooter(record)}
  </article>`;
}

// Note affordance on the left, tab actions on the right, so every row lines up.
function attentionItemFooter(record) {
  return `<div class="pickup-footer">
    <button class="pickup-add-note" type="button" data-action="edit-tab-note" data-tab-id="${record.tabId}">${record.note ? "Edit note" : "+ Add note"}</button>
    <span class="pickup-footer-spacer"></span>
    ${record.needsAttention ? `<button class="pickup-done" type="button" data-action="tab-snooze" data-tab-id="${record.tabId}">Snooze</button>` : ""}
    <button class="pickup-done" type="button" data-action="tab-done" data-tab-id="${record.tabId}">${record.needsAttention ? "Done" : "Cancel"}</button>
  </div>`;
}

// An optional note on a reminder ("check Gemini's answer"), shown in the panel
// and in the notification.
function tabNoteEditor(record) {
  return `<div class="pickup-note-editor"><label class="pickup-note-label" for="tab-note-input"><span>Note (optional)</span><input class="pickup-note" id="tab-note-input" data-note-key="${record.tabId}" type="text" maxlength="${CogniFlow.NOTE_MAX_LENGTH}" value="${escapeHtml(record.note || "")}" placeholder="What to do when you come back" aria-label="Optional note for ${escapeHtml(record.title || record.hostname)}" /></label><div class="pickup-note-actions"><button class="pickup-note-cancel" type="button" data-action="cancel-tab-note">Cancel</button><button class="pickup-note-save" type="button" data-action="save-tab-note" data-tab-id="${record.tabId}">Save note</button></div></div>`;
}

function workflowCard(item, selectedId) {
  const active = (item.tabs || []).find(tab => tab.url === item.activeUrl);
  const openTabs = (item.tabs || []).filter(CogniFlow.isOpenTab);
  const closedCount = (item.tabs || []).length - openTabs.length;
  // The card is titled after the anchor tab, so name its site, not whichever
  // tab was in front when the capture ran.
  const anchor = (item.tabs || []).find(tab => tab.url === item.anchorUrl) || CogniFlow.workflowAnchor(item.tabs, item.activeUrl);
  const domains = [...new Set(openTabs.map(tab => tab.hostname).filter(Boolean))].slice(0,4);
  // The active tab's title is usually what the workflow is named after; only
  // show it again when it actually adds something.
  const preview = (active?.title || "").trim();
  const subtitle = preview && preview !== (item.title || "").trim() ? preview : "";
  const tabCount = openTabs.length;
  return `<button class="card workflow-card ${selectedId === item.id ? "is-selected" : ""} ${state.pendingReturn?.workflowId === item.id && state.pendingReturn?.notifiedAt ? "is-returned" : ""}" data-action="select-workflow" data-id="${escapeHtml(item.id)}" aria-label="Open ${escapeHtml(item.title)}">
    <span class="workflow-head"><span class="workflow-source">${escapeHtml(anchor?.hostname || active?.hostname || item.tabs?.[0]?.hostname || "Browser workflow")}</span><span class="workflow-time">${timeLabel(item.lastActive)}</span></span>
    <span class="workflow-title">${escapeHtml(item.title || "Untitled workflow")}</span>
    <span class="workflow-meta">${subtitle ? `<span class="workflow-preview">${escapeHtml(subtitle)}</span>` : "<span></span>"}<span>${tabCount} open${closedCount ? ` · ${closedCount} closed` : ""}</span></span>
    <span class="chips">${domains.map(domain => `<span class="chip">${escapeHtml(domain)}</span>`).join("")}</span>
  </button>`;
}

// Tabs grouped by what they were opened from. With nothing to group — no
// links followed — this is just the flat list, so the structure appears only
// when it means something.
function threadSections(tabs, activeUrl) {
  const { threads, loose } = CogniFlow.relatedThreads(tabs);
  const card = items => `<div class="card saved-tabs-card"><div class="tab-list">${items.map(tab => savedTab(tab, activeUrl)).join("")}</div></div>`;
  if (!threads.length) return card(tabs);
  return threads.map(thread => `<p class="section-kicker thread-kicker">Opened from ${escapeHtml(thread.root.title || thread.root.hostname)}</p>${card(thread.tabs)}`).join("")
    + (loose.length ? `<p class="section-kicker thread-kicker">Opened on their own</p>${card(loose)}` : "");
}

// `showOrigin` is for flat lists, where no heading says what a tab came from.
function savedTab(tab, activeUrl, showOrigin = false) {
  const title = tab.title || tab.hostname || "Untitled tab";
  // Malformed or non-web saved URLs stay visible but not clickable.
  const safeUrl = safeWebUrl(tab.url);
  const tag = safeUrl ? "button" : "div";
  const buttonAttributes = safeUrl ? 'type="button" data-action="open-saved-tab" data-url="' + escapeHtml(safeUrl) + '" aria-label="Open ' + escapeHtml(title) + ' in a new tab"' : "";
  const closed = !CogniFlow.isOpenTab(tab);
  const className = "saved-tab" + (safeUrl ? " is-openable" : "") + (closed ? " is-closed" : "") + (!closed && tab.url === activeUrl ? " is-last-active" : "");
  // How long you were in this tab, where that is known and worth saying.
  const spent = (tab.activeMs || 0) >= 60_000 ? ` · ${durationLabel(tab.activeMs)}` : "";
  // Saying "figma.com · from figma.com" tells the reader nothing.
  const originHost = showOrigin && tab.openedFrom ? CogniFlow.hostOf(tab.openedFrom) : "";
  const origin = originHost && originHost !== tab.hostname ? ` · from ${originHost}` : "";
  const hostLabel = (tab.hostname || "Website") + spent + origin + (closed ? ` · Closed ${timeLabel(tab.closedAt)}` : (tab.url === activeUrl ? " · Last active" : ""));
  const savedLabel = safeUrl ? (closed ? "Reopen ↗" : "Open tab ↗") : (tab.url === activeUrl ? "Last active" : "Saved");
  return "<" + tag + ' class="' + className + '" ' + buttonAttributes + '><span class="saved-host">' + escapeHtml(hostLabel) + '</span><span class="saved-time">' + escapeHtml(savedLabel) + '</span><span class="saved-title">' + escapeHtml(title) + "</span></" + tag + ">";
}

function returnBanner() {
  const pending = state.pendingReturn;
  if (!pending?.notifiedAt) return "";
  const workflow = state.workflows.find(item => item.id === pending.workflowId);
  if (!workflow) return "";
  const tab = workflow.tabs?.find(item => item.url === workflow.activeUrl);
  return `<section class="return-banner" role="status"><div class="return-icon" aria-hidden="true">↩</div><div class="return-copy"><strong>Welcome back</strong><span>Your last tab: ${escapeHtml(tab?.title || workflow.activeTitle || workflow.title)}${tab?.hostname ? ` · ${escapeHtml(tab.hostname)}` : ""}</span></div><button class="button return-button" data-action="resume-return" data-id="${escapeHtml(workflow.id)}">Go to tab</button><button class="return-dismiss" data-action="dismiss-return" aria-label="Dismiss return reminder">×</button></section>`;
}

function emptyState(title = "Your work will appear here", copy = "Once memory is enabled, CogniFlow will quietly save tab context so you can resume after an interruption.") {
  return `<section class="card empty"><div class="welcome-illustration" aria-hidden="true">${lockIcon()}</div><h2>${escapeHtml(title)}</h2><p>${escapeHtml(copy)}</p>${state.trackingEnabled ? `<button class="button secondary" data-action="capture">Save this window now</button>` : `<button class="button secondary" data-view="settings">Review privacy settings</button>`}</section>`;
}

// Rounded to the minute: this is "roughly how long", not a stopwatch.
function durationLabel(ms) {
  const totalMinutes = Math.round((ms || 0) / 60_000);
  if (totalMinutes < 1) return "under a minute";
  if (totalMinutes < 60) return `${totalMinutes} min`;
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return minutes ? `${hours}h ${minutes}m` : `${hours}h`;
}

function summaryText(workflow) {
  const tabs = workflow.tabs || [];
  const open = tabs.filter(CogniFlow.isOpenTab).length;
  const closed = tabs.length - open;
  const anchor = tabs.find(tab => tab.url === workflow.anchorUrl) || CogniFlow.workflowAnchor(tabs, workflow.activeUrl);
  const openPart = `${open} tab${open === 1 ? "" : "s"} still open`;
  const closedPart = closed ? `, and ${closed} you have since closed` : "";
  const spentPart = anchor && (anchor.activeMs || 0) > 0
    ? `Most of your time went to ${anchor.hostname} — about ${durationLabel(anchor.activeMs)}. `
    : "";
  return `${spentPart}${openPart}${closedPart}.`;
}

function filteredWorkflows() {
  const term = searchTerm.trim().toLowerCase();
  const items = [...state.workflows].sort((a,b) => (b.lastActive || 0) - (a.lastActive || 0));
  if (!term) return items;
  return items.filter(item => `${item.title} ${(item.tabs || []).map(tab => `${tab.title} ${tab.hostname}`).join(" ")}`.toLowerCase().includes(term));
}

function lockIcon() {
  return `<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="4" y="8" width="12" height="9" rx="2"/><path d="M6.5 8V5.8a3.5 3.5 0 0 1 7 0V8"/></svg>`;
}

function bindEvents() {
  app.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click", () => {
    // Keep the selected workflow so the Related tab still shows it.
    if (button.dataset.view) { activeView = button.dataset.view; render(); }
  }));
  app.querySelectorAll("[data-action]").forEach(button => button.addEventListener("click", () => {
    // Chrome API calls can reject (a permission prompt outside a gesture, a
    // closed window); tell the user instead of failing silently.
    handleAction(button).catch(error => {
      console.error("CogniFlow action failed.", button.dataset.action, error);
      showToast("Something went wrong. Try again.");
    });
  }));
  const consent = document.getElementById("consent");
  if (consent) consent.addEventListener("change", () => { document.getElementById("start").disabled = !consent.checked; });
  document.getElementById("start")?.addEventListener("click", () => startOnboarding().catch(error => {
    console.error("CogniFlow onboarding failed.", error);
    showToast("Could not enable memory. Try again.");
  }));
  document.getElementById("search")?.addEventListener("input", event => { searchTerm = event.target.value; render(); });
  document.getElementById("domain-form")?.addEventListener("submit", addExcludedDomain);
  document.getElementById("reminder-minutes")?.addEventListener("change", saveReminderTime);
  document.getElementById("show-tab-title")?.addEventListener("change", saveTabTitlePreference);
  document.getElementById("tab-reminder-minutes")?.addEventListener("change", saveTabReminderTime);
  document.getElementById("blink-toolbar-icon")?.addEventListener("change", event => {
    state.blinkToolbarIcon = event.target.checked;
    chrome.storage.local.set({ blinkToolbarIcon: state.blinkToolbarIcon });
  });
}

async function handleAction(button) {
  const { action, id, domain } = button.dataset;
  if (action === "select-workflow") { selectedWorkflowId = id; activeView = "related"; render(); }
  if (action === "open-saved-tab") await openSavedTab(button.dataset.url);
  if (action === "toggle-attention") {
    attentionExpanded = !attentionExpanded;
    writePreference("cogniflow.attentionExpanded", String(attentionExpanded));
    render();
    document.querySelector(".attention-toggle")?.focus();
  }
  if (action === "edit-tab-note") { editingNoteTabId = Number(button.dataset.tabId); render(); document.getElementById("tab-note-input")?.focus(); }
  if (action === "save-tab-note") await saveTabNote(button);
  if (action === "cancel-tab-note") { editingNoteTabId = null; render(); }
  if (action === "back") { selectedWorkflowId = null; activeView = "recent"; render(); }
  if (action === "toggle-memory") await toggleMemory();
  if (action === "toggle-reminders") await toggleReminders();
  if (action === "test-reminder") await testReminder();
  if (action === "resume-return") await goToLastTab(id);
  if (action === "dismiss-return") await dismissReturnHighlight();
  if (action === "capture") await captureNow();
  if (action === "continue") await continueWorkflow(id);
  if (action === "delete-workflow") await deleteWorkflow(id);
  if (action === "clear-data") await clearData();
  if (action === "remove-domain") await removeDomain(domain);
  if (action === "tab-go") await goToWatchedTab(Number(button.dataset.tabId));
  if (action === "tab-snooze") await runTabReminderOp({ kind: "snooze", tabId: Number(button.dataset.tabId) }, "Snoozed for 10 minutes.");
  if (action === "tab-done") await runTabReminderOp({ kind: "done", tabId: Number(button.dataset.tabId) }, "Marked done. No more reminders for this tab.");
  if (action === "remind-current") await remindAboutCurrentTab();
  if (action === "toggle-tab-reminders") await toggleTabReminders();
}

async function startOnboarding() {
  const granted = await chrome.permissions.request({ permissions: ["tabs"] });
  if (!granted) { showToast("Tab access was not granted. CogniFlow did not capture anything."); return; }
  state.onboardingComplete = true;
  state.trackingEnabled = true;
  await chrome.storage.local.set({ onboardingComplete: true, trackingEnabled: true });
  render();
  await captureNow(true);
}

async function toggleMemory() {
  if (state.trackingEnabled) {
    state.trackingEnabled = false;
    await chrome.storage.local.set({ trackingEnabled: false });
    await clearReturnState();
    showToast("Memory paused. Existing saved workflows remain on this device.");
  } else {
    // Call request() first: an earlier await can drop the user gesture Chrome
    // requires. It resolves true right away if access is already granted.
    const granted = await chrome.permissions.request({ permissions: ["tabs"] }).catch(() => false);
    if (!granted) { showToast("Tab access is needed to save browser context."); return; }
    state.trackingEnabled = true;
    await chrome.storage.local.set({ trackingEnabled: true });
    await captureNow(true);
    showToast("Memory resumed.");
  }
  render();
}

async function toggleReminders() {
  if (state.idleRemindersEnabled) {
    state.idleRemindersEnabled = false;
    await chrome.storage.local.set({ idleRemindersEnabled: false });
    await clearReturnState();
    await chrome.runtime.sendMessage({ type: "CONFIGURE_REMINDERS" }).catch(() => undefined);
    showToast("Turned off. You won't be reminded when you come back.");
  } else {
    const granted = await chrome.permissions.request({ permissions: ["idle", "notifications"] });
    if (!granted) { showToast("CogniFlow needs permission to send notifications for this."); return; }
    state.idleRemindersEnabled = true;
    await chrome.storage.local.set({ idleRemindersEnabled: true });
    await chrome.runtime.sendMessage({ type: "CONFIGURE_REMINDERS" }).catch(() => undefined);
    showToast(`On. After ${state.reminderMinutes} minutes away, you'll see where you left off.`);
  }
  render();
}

async function saveReminderTime(event) {
  state.reminderMinutes = Number(event.target.value) || 10;
  await chrome.storage.local.set({ reminderMinutes: state.reminderMinutes });
  if (state.idleRemindersEnabled) await chrome.runtime.sendMessage({ type: "CONFIGURE_REMINDERS" }).catch(() => undefined);
  showToast(`You now count as away after ${state.reminderMinutes} minutes.`);
}

async function saveTabTitlePreference(event) {
  state.showTabTitleInReturnAlert = event.target.checked;
  await chrome.storage.local.set({ showTabTitleInReturnAlert: state.showTabTitleInReturnAlert });
}

async function testReminder() {
  if (window.COGNIFLOW_PREVIEW) { showToast("Preview only: a system notification would appear here."); return; }
  const result = await chrome.runtime.sendMessage({ type: "TEST_REMINDER" }).catch(error => ({ ok: false, error: error?.message }));
  showToast(result?.ok ? "Test reminder sent." : result?.error ? `Could not send reminder: ${result.error}` : "Could not send a reminder. Check Chrome notification settings.");
}

async function captureNow(silent = false) {
  if (!state.trackingEnabled) { if (!silent) showToast("Resume memory in Settings first."); return; }
  const win = await chrome.windows.getLastFocused().catch(() => null);
  const response = await chrome.runtime.sendMessage({ type: "CAPTURE_NOW", windowId: win?.id }).catch(error => ({ ok: false, error: error?.message }));
  await loadState();
  if (!silent) showToast(response?.ok && response.result?.tabCount ? `Saved ${response.result.tabCount} tabs on this device.` : "No eligible browser tabs to save.");
}

async function openSavedTab(url) {
  const safeUrl = safeWebUrl(url);
  if (!safeUrl) { showToast("Only valid web pages can be opened from saved work."); return; }
  try {
    if (window.COGNIFLOW_PREVIEW) {
      const openedWindow = window.open(safeUrl, "_blank", "noopener,noreferrer");
      if (!openedWindow) { showToast("Allow pop-ups to open this saved tab."); return; }
    } else {
      await chrome.tabs.create({ url: safeUrl, active: true });
    }
    showToast("Opened this tab in a new browser tab.");
  } catch {
    showToast("Could not open this saved tab. Try again.");
  }
}

// Switch to an open tab showing this URL, or open it if none is. Returns
// whether a tab ended up active.
async function focusOrOpenTab(url) {
  const matchingTabs = await chrome.tabs.query({ url }).catch(() => []);
  const existing = matchingTabs.find(tab => Number.isInteger(tab.id));
  if (existing) {
    try {
      await chrome.tabs.update(existing.id, { active: true });
      await chrome.windows.update(existing.windowId, { focused: true }).catch(() => undefined);
      return true;
    } catch { /* The tab closed after the query; open a replacement below. */ }
  }
  try {
    await chrome.tabs.create({ url, active: true });
    return true;
  } catch {
    return false;
  }
}

// The service worker owns `workflows`: it applies every change in the same
// queue as tab captures, so an edit here can't erase a capture (or vice versa).
// The panel redraws from chrome.storage.onChanged once the write lands.
async function runWorkflowOp(op) {
  const response = await chrome.runtime.sendMessage({ type: "WORKFLOW_OP", op })
    .catch(error => ({ ok: false, error: error?.message }));
  if (!response?.ok) {
    showToast(`Could not update saved work${response?.error ? `: ${response.error}` : "."}`);
    return false;
  }
  await loadState();
  return true;
}

async function saveTabNote(button) {
  const input = document.getElementById("tab-note-input");
  const note = input?.value.trim() || "";
  const result = await runTabReminderOp({ kind: "set-note", tabId: Number(button.dataset.tabId), note }, note ? "Note saved on this device." : "Note removed.");
  if (!result) return;
  editingNoteTabId = null;
  render();
}

async function continueWorkflow(id) {
  const workflow = state.workflows.find(item => item.id === id);
  if (!workflow) return;
  // Only the tabs that were open: closed ones are reopened one at a time from
  // the Related view, so "Continue Work" restores the workspace rather than
  // every page the workflow ever touched.
  const tabs = (workflow.tabs || []).filter(CogniFlow.isOpenTab).map(tab => ({ ...tab, url: safeWebUrl(tab?.url) })).filter(tab => tab.url);
  if (!tabs.length) { showToast("No valid web tabs were saved in this workflow."); return; }
  const lastActive = tabs.find(tab => tab.url === safeWebUrl(workflow.activeUrl)) || tabs[0];
  const otherTabs = tabs.filter(tab => tab.url !== lastActive.url);
  let openedCount = 0;
  for (const tab of otherTabs) {
    try { await chrome.tabs.create({ url: tab.url, active: false }); openedCount += 1; } catch { /* Continue opening the remaining tabs. */ }
  }
  try { await chrome.tabs.create({ url: lastActive.url, active: true }); openedCount += 1; } catch { /* Report the number that did open. */ }
  showToast(openedCount === tabs.length ? "Reopened " + openedCount + " saved tabs." : "Opened " + openedCount + " of " + tabs.length + " saved tabs.");
}

async function goToLastTab(id) {
  const workflow = state.workflows.find(item => item.id === id);
  if (!workflow) return;
  const targetUrl = safeWebUrl(workflow.activeUrl) || safeWebUrl(workflow.tabs?.[0]?.url);
  if (!targetUrl) return;
  if (!await focusOrOpenTab(targetUrl)) { showToast("Could not reopen this tab. Try again."); return; }
  await dismissReturnHighlight();
  showToast("Returned to the last active tab.");
}

// The service worker recomputes the toolbar badge when this changes.
async function clearReturnState() {
  state.pendingReturn = null;
  await chrome.storage.local.set({ pendingReturn: null, lastReminderWindowId: null });
}

async function runTabReminderOp(op, successMessage) {
  const response = await chrome.runtime.sendMessage({ type: "TAB_REMINDER_OP", op })
    .catch(error => ({ ok: false, error: error?.message }));
  if (!response?.ok) {
    showToast(response?.error || "Could not update this reminder.");
    return null;
  }
  await loadState();
  if (successMessage) showToast(successMessage);
  return response.result;
}

async function remindAboutCurrentTab() {
  // Ask first, while the click still counts as a user gesture. Without
  // notifications the reminder still shows in this panel and on the badge.
  const canNotify = await chrome.permissions.request({ permissions: ["notifications"] }).catch(() => false);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }).catch(() => []);
  if (!tab) { showToast("Open the page you want a reminder for, then try again."); return; }
  const result = await runTabReminderOp({ kind: "remind", tabId: tab.id, minutes: tabReminderMinutes() });
  if (result) showToast(`I'll remind you about this tab in ${result.minutes} min${canNotify ? "" : " (in this panel; notifications are off)"}.`);
}

async function goToWatchedTab(tabId) {
  const record = state.tabWatch.tabs[tabId];
  try {
    const tab = await chrome.tabs.get(tabId);
    await chrome.tabs.update(tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => undefined);
  } catch {
    // The tab was closed; reopen the page instead.
    const url = safeWebUrl(record?.url);
    if (!url || !await focusOrOpenTab(url)) { showToast("That tab is closed and couldn't be reopened."); return; }
  }
}

async function toggleTabReminders() {
  if (state.tabRemindersEnabled) {
    state.tabRemindersEnabled = false;
    await chrome.storage.local.set({ tabRemindersEnabled: false });
    showToast("Turned off. Reminders you set yourself still work.");
  } else {
    // idle lets CogniFlow hold reminders while you're away from the device.
    const granted = await chrome.permissions.request({ permissions: ["notifications", "idle"] }).catch(() => false);
    if (!granted) { showToast("CogniFlow needs permission to send notifications for this."); return; }
    state.tabRemindersEnabled = true;
    await chrome.storage.local.set({ tabRemindersEnabled: true });
    showToast(`On. You'll be nudged about tabs left for ${tabReminderMinutes()} minutes.`);
  }
  render();
}

async function saveTabReminderTime(event) {
  const minutes = Number(event.target.value);
  state.tabReminderMinutes = CogniFlow.TAB_REMINDER_MINUTES.includes(minutes) ? minutes : DEFAULTS.tabReminderMinutes;
  await chrome.storage.local.set({ tabReminderMinutes: state.tabReminderMinutes });
  showToast(`You'll be nudged after a tab sits for ${state.tabReminderMinutes} minutes.`);
}

async function dismissReturnHighlight() {
  await clearReturnState();
  render();
}

async function deleteWorkflow(id) {
  if (!await runWorkflowOp({ kind: "delete-workflow", workflowId: id })) return;
  selectedWorkflowId = null; activeView = "recent";
  render(); showToast("Workflow removed from this device.");
}

async function clearData() {
  if (!confirm("Delete every saved workflow from this device? This cannot be undone.")) return;
  await clearReturnState();
  if (!await runWorkflowOp({ kind: "clear-all" })) return;
  selectedWorkflowId = null; activeView = "recent";
  render(); showToast("All saved work was deleted.");
}

async function addExcludedDomain(event) {
  event.preventDefault();
  const input = document.getElementById("domain-input");
  const domain = CogniFlow.parseDomainInput(input.value);
  if (!domain) { showToast("Enter a valid domain, such as example.com."); return; }
  // Adds the domain and removes its saved tabs in one step.
  if (!await runWorkflowOp({ kind: "exclude-domain", domain })) return;
  document.getElementById("domain-input").value = "";
  render(); showToast(`${domain} added to private sites.`);
}

async function removeDomain(domain) {
  if (!await runWorkflowOp({ kind: "include-domain", domain })) return;
  showToast(`${domain} removed from private sites.`);
}

function showToast(message) {
  clearTimeout(toastTimer);
  document.querySelector(".toast")?.remove();
  const toast = document.createElement("div");
  toast.className = "toast"; toast.setAttribute("role","status"); toast.textContent = message;
  document.body.append(toast);
  toastTimer = setTimeout(() => toast.remove(), 2600);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.onboardingComplete || changes.workflows || changes.trackingEnabled || changes.idleRemindersEnabled || changes.reminderMinutes || changes.showTabTitleInReturnAlert || changes.excludedDomains || changes.pendingReturn || changes.tabWatch || changes.tabRemindersEnabled || changes.tabReminderMinutes)) loadState();
});

loadState();
