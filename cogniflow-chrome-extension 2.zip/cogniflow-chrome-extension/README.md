# CogniFlow Chrome extension prototype

CogniFlow is a local-first workflow-continuity prototype. It keeps a small browser-tab memory so someone can return to work after an interruption.

## What works

- Chrome Manifest V3 side panel with **Recent Work**, **Related**, and **Settings** views.
- Explicit onboarding consent and an optional Chrome `tabs` permission request before capture begins.
- Quiet capture of tab titles, URLs, hostnames, active-tab state, and timestamps when tabs change or the browser window regains focus.
- Excluded-domain controls, pause/resume, per-workflow deletion, and delete-all controls.
- **When you come back** (Settings): optional return alerts after 5, 10, or 15 minutes of system-wide idle, with a test notification, toolbar badge, highlighted last tab, and click-to-open behavior.
- Open any saved tab individually from the Related view, or resume a whole workflow by reopening its saved URLs and activating the last active tab.
- **While you're working** (Settings), shown in the panel as **Waiting on you**: reminders about open tabs you left mid-task, delivered while you keep working (not only after idle). Three signals, all from tab metadata:
  1. **Reminders you set**: press `Alt+Shift+W` (or use the panel) on a tab, such as an AI chat running a task, and CogniFlow notifies you after 10, 20 or 30 minutes unless you go back first.
  2. **Forgotten tabs**: with *While you're working* on, a tab you spent at least 30 seconds on, left open and haven't revisited for the chosen time is flagged.
  3. **Changed after you left**: if such a tab's title changes after you leave (an AI answer finishing, a new message), it's flagged sooner.
  Each reminder can carry an optional note ("check Gemini's answer") shown in the panel and the notification. Each notification offers Go back (click), Snooze 10 min, or Done. Automatic reminders are at least 15 minutes apart and are held while the device is idle. The toolbar badge counts what's waiting, and the toolbar icon turns orange: it blinks for about 12 seconds when a new alert arrives, then pulses briefly once a minute until you go back, snooze or mark it done (Settings can turn the blinking off).
- **Workflows are named after where the time went**: the anchor tab is the one with the most time in it (`activeMs`, read from the reminder tracker's `engagedMs`), not whichever tab was in front when the capture ran. The name therefore stays put while you switch tabs, and moves only when the work does. The last active tab is still recorded separately for the return alert.
- **Workflows split on tab turnover, not only the clock**: a capture extends the workflow in progress unless 20 minutes have passed *or* fewer than `WORKFLOW_TURNOVER_RATIO` of its open tabs survive. Finishing one task and opening a different set of tabs starts a new workflow with no pause needed; a ten-minute interruption in the middle of one task no longer splits it. Turnover is only judged once there were at least three tabs to turn over.
- **Related means related**: capture records `openerTabId` as `openedFrom` (the opener's URL), so the Related view groups tabs into the threads you actually opened — "Opened from CogniFlow landing page — Figma" — with tabs you opened directly listed under "Opened on their own". `relatedThreads` in `shared.js` walks each tab's chain to its root with a depth cap and a seen-set, so broken links and loops resolve rather than hang, and a group of one is never presented as a thread. The opener lookup is built from eligible tabs only, so an excluded or non-web opener leaves no link instead of writing its URL into a tab that is kept; excluding a site later scrubs links already stored.
- **Closed tabs are kept**: a capture sees only what is open now, so each one is *merged* into the workflow instead of replacing it. A tab you close stays in the record with a `closedAt` time and appears under **You closed these** in the Related view, with a **Reopen** action. This is the part the browser itself cannot do — Chrome forgets a tab the moment it closes. A URL open for less than 30 seconds is dropped rather than kept, so passing through search results doesn't fill the list; a URL you return to becomes live again instead of duplicating; **Continue Work** reopens only the tabs that were open, so it restores the workspace rather than every page the workflow ever touched.
- **24-hour retention**: saved workflows and watched tabs are deleted once they are a day old. Expiry lives in `sanitizeWorkflows`/`sanitizeTabWatch` in `shared.js`, which every read and write calls, and a 30-minute alarm plus startup sweep (`pruneExpiredData`) removes them from storage.
- Local persistence in `chrome.storage.local`, including per-tab activity timestamps and optional user notes; no account, server, analytics, page-content script, screenshots, message capture, or keystroke capture.

## Load it in Chrome

1. Open `chrome://extensions`.
2. Turn on **Developer mode**.
3. Choose **Load unpacked** and select this folder.
4. Open the CogniFlow side panel from the extension toolbar button.
5. Review the data explanation, check the consent box, and choose **Enable local memory**. Chrome then asks for optional tab access.
6. In **Settings**, enable **Idle reminder** and allow its separate idle and notification permissions. Choose a delay and use **Send a test reminder** to confirm notification delivery. After that period with no device input, the next input that returns the system to active state triggers the notification.

The extension requests tab access only after the user's action. Idle and notification permissions are requested separately when reminders are enabled. If a permission is declined or revoked, that feature turns off. The idle signal is system-wide, so it measures inactivity across the device rather than only in Chrome. On return, CogniFlow shows a system notification, a toolbar badge, and a highlighted in-panel reminder with a **Go to tab** action; it does not steal focus automatically. The implementation stores full URLs so it can reopen tabs; users should exclude sensitive domains or pause memory when needed.

## Prototype boundary

This is a working concept prototype, not a published or security-audited extension. Workflow grouping is a heuristic over tab metadata — dwell time, tab turnover and a 20-minute idle gap. It does not infer intent or summarize page contents, so a workflow is named after the tab you spent longest in, which is a proxy for what you were doing, not a description of it. The case-study targets (including under 30 seconds to resume and a 50% reduction in reconstruction time) are hypotheses and have not been measured by this code.

## How the code is organized

- `shared.js` holds the storage defaults, limits and data rules (domain parsing, URL safety, workflow edits). The service worker loads it with `importScripts`; the side panel and preview load it with a `<script>` tag.
- `mergeWorkflowTabs` in `shared.js` is what makes the memory additive: it diffs the tabs open now against the ones the workflow already held, marks the missing ones closed, and keeps the most recent of them up to `MAX_WORKFLOW_TABS` (open tabs are never evicted). `captureWindow` filters excluded domains out of the remembered tabs before merging, so adding a private site clears it from the closed list too.
- `service-worker.js` is the only code that writes `workflows` and `excludedDomains`. Tab captures (debounced per window), idle/return handling and side panel edits (`WORKFLOW_OP` messages) run one at a time in a single queue, so they can't overwrite each other. Incognito windows are never captured (`"incognito": "not_allowed"`).
- `sidepanel.js` renders from `chrome.storage.local` and redraws when it changes. Settings such as pause and reminders are written directly from the panel.
- Forgotten-tab reminders keep a per-tab record in `tabWatch` (time spent, when you left, title changes, reminders). The rules are in `shared.js` (`dueTabReminders`, `applyTabReminderOp`); the worker updates records on tab and focus events and checks them every minute with a `chrome.alarms` alarm, since the worker itself can be stopped at any time.
- `preview.html` + `preview-bridge.js` run the side panel in a normal browser tab with mock Chrome APIs and sample data.

## Technical references

- [Chrome Side Panel API](https://developer.chrome.com/docs/extensions/reference/api/sidePanel)
- [Chrome Tabs API](https://developer.chrome.com/docs/extensions/reference/api/tabs)
- [Chrome Storage API](https://developer.chrome.com/docs/extensions/reference/api/storage)
